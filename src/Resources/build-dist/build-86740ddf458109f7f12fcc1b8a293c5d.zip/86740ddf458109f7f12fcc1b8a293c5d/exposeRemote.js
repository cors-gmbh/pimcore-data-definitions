
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.datadefinitions = "/bundles/datadefinitions/studio/86740ddf458109f7f12fcc1b8a293c5d/static/js/remoteEntry.js"

      
    