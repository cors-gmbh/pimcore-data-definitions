
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.datadefinitions = "/bundles/datadefinitions/studio/10b9ee798549574618e3149914ad07ef/static/js/remoteEntry.js"

      
    