/*! For license information please see main.855bddbf.js.LICENSE.txt */
(()=>{"use strict";var __webpack_modules__={7022(e,t){let r="RUNTIME-001",o="RUNTIME-002",n="RUNTIME-003",i="RUNTIME-004",a="RUNTIME-005",s="RUNTIME-006",l="RUNTIME-007",c="RUNTIME-008",u="TYPE-001",d="BUILD-001",p=e=>{let t=e.split("-")[0].toLowerCase();return`View the docs to see how to solve: https://module-federation.io/guide/troubleshooting/${t}/${e}`},f=(e,t,r,o)=>{let n=[`${[t[e]]} #${e}`];return r&&n.push(`args: ${JSON.stringify(r)}`),n.push(p(e)),o&&n.push(`Original Error Message:
 ${o}`),n.join("\n")};function h(){return(h=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var o in r)Object.prototype.hasOwnProperty.call(r,o)&&(e[o]=r[o])}return e}).apply(this,arguments)}let m={[r]:"Failed to get remoteEntry exports.",[o]:'The remote entry interface does not contain "init"',[n]:"Failed to get manifest.",[i]:"Failed to locate remote.",[a]:"Invalid loadShareSync function call from bundler runtime",[s]:"Invalid loadShareSync function call from runtime",[l]:"Failed to get remote snapshot.",[c]:"Failed to load script resources."},g={[u]:"Failed to generate type declaration. Execute the below cmd to reproduce and fix the error."},y={[d]:"Failed to find expose module."},_=h({},m,g,y);t.BUILD_001=d,t.RUNTIME_001=r,t.RUNTIME_002=o,t.RUNTIME_003=n,t.RUNTIME_004=i,t.RUNTIME_005=a,t.RUNTIME_006=s,t.RUNTIME_007=l,t.RUNTIME_008=c,t.TYPE_001=u,t.buildDescMap=y,t.errorDescMap=_,t.getShortErrorMsg=f,t.runtimeDescMap=m,t.typeDescMap=g},2104(e,t){t.FEDERATION_SUPPORTED_TYPES=["script"]},264(e,t,r){var o=r(5646),n=r(2104),i=r(318);function a(e){e.S&&!e.federation.hasAttachShareScopeMap&&e.federation.instance&&e.federation.instance.shareScopeMap&&(e.S=e.federation.instance.shareScopeMap,e.federation.hasAttachShareScopeMap=!0)}function s(e){let{chunkId:t,promises:r,chunkMapping:o,idToExternalAndNameMapping:s,webpackRequire:l,idToRemoteMap:c}=e;a(l),l.o(o,t)&&o[t].forEach(e=>{let t=l.R;t||(t=[]);let o=s[e],a=c[e];if(t.indexOf(o)>=0)return;if(t.push(o),o.p)return r.push(o.p);let u=t=>{t||(t=Error("Container missing")),"string"==typeof t.message&&(t.message+=`
while loading "${o[1]}" from ${o[2]}`),l.m[e]=()=>{throw t},o.p=0},d=(e,t,n,i,a,s)=>{try{let l=e(t,n);if(!l||!l.then)return a(l,i,s);{let e=l.then(e=>a(e,i),u);if(!s)return e;r.push(o.p=e)}}catch(e){u(e)}},p=(e,t,r)=>e?d(l.I,o[0],0,e,f,r):u();var f=(e,r,n)=>d(r.get,o[1],t,0,h,n),h=t=>{o.p=1,l.m[e]=e=>{e.exports=t()}};let m=()=>{try{let e=i.decodeName(a[0].name,i.ENCODE_NAME_PREFIX)+o[1].slice(1),t=l.federation.instance,r=()=>l.federation.instance.loadRemote(e,{loadFactory:!1,from:"build"});if("version-first"===t.options.shareStrategy)return Promise.all(t.sharedHandler.initializeSharing(o[0])).then(()=>r());return r()}catch(e){u(e)}};1===a.length&&n.FEDERATION_SUPPORTED_TYPES.includes(a[0].externalType)&&a[0].name?d(m,o[2],0,0,h,1):d(l,o[2],0,0,p,1)})}function l(e){let{chunkId:t,promises:r,chunkMapping:o,installedModules:n,moduleToHandlerMapping:i,webpackRequire:s}=e;a(s),s.o(o,t)&&o[t].forEach(e=>{if(s.o(n,e))return r.push(n[e]);let t=t=>{n[e]=0,s.m[e]=r=>{delete s.c[e],r.exports=t()}},o=t=>{delete n[e],s.m[e]=r=>{throw delete s.c[e],t}};try{let a=s.federation.instance;if(!a)throw Error("Federation instance not found!");let{shareKey:l,getter:c,shareInfo:u}=i[e],d=a.loadShare(l,{customShareInfo:u}).then(e=>!1===e?c():e);d.then?r.push(n[e]=d.then(t).catch(o)):t(d)}catch(e){o(e)}})}function c(e){let{shareScopeName:t,webpackRequire:r,initPromises:o,initTokens:i,initScope:s}=e,l=Array.isArray(t)?t:[t];var c=[],u=function(e){s||(s=[]);let l=r.federation.instance;var c=i[e];if(c||(c=i[e]={from:l.name}),s.indexOf(c)>=0)return;s.push(c);let u=o[e];if(u)return u;var d=e=>"u">typeof console&&console.warn&&console.warn(e),p=o=>{var n=e=>d("Initialization of sharing external failed: "+e);try{var i=r(o);if(!i)return;var a=o=>o&&o.init&&o.init(r.S[e],s,{shareScopeMap:r.S||{},shareScopeKeys:t});if(i.then)return f.push(i.then(a,n));var l=a(i);if(l&&"boolean"!=typeof l&&l.then)return f.push(l.catch(n))}catch(e){n(e)}};let f=l.initializeSharing(e,{strategy:l.options.shareStrategy,initScope:s,from:"build"});a(r);let h=r.federation.bundlerRuntimeOptions.remotes;return(h&&Object.keys(h.idToRemoteMap).forEach(e=>{let t=h.idToRemoteMap[e],r=h.idToExternalAndNameMapping[e][2];if(t.length>1)p(r);else if(1===t.length){let e=t[0];n.FEDERATION_SUPPORTED_TYPES.includes(e.externalType)||p(r)}}),f.length)?o[e]=Promise.all(f).then(()=>o[e]=!0):o[e]=!0};return l.forEach(e=>{c.push(u(e))}),Promise.all(c).then(()=>!0)}function u(e){let{moduleId:t,moduleToHandlerMapping:r,webpackRequire:o}=e,n=o.federation.instance;if(!n)throw Error("Federation instance not found!");let{shareKey:i,shareInfo:a}=r[t];try{return n.loadShareSync(i,{customShareInfo:a})}catch(e){throw console.error('loadShareSync failed! The function should not be called unless you set "eager:true". If you do not set it, and encounter this issue, you can check whether an async boundary is implemented.'),console.error("The original error message is as follows: "),e}}function d(e){let{moduleToHandlerMapping:t,webpackRequire:r,installedModules:o,initialConsumes:n}=e;n.forEach(e=>{r.m[e]=n=>{o[e]=0,delete r.c[e];let i=u({moduleId:e,moduleToHandlerMapping:t,webpackRequire:r});if("function"!=typeof i)throw Error(`Shared module is not available for eager consumption: ${e}`);n.exports=i()}})}function p(){return(p=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var o in r)Object.prototype.hasOwnProperty.call(r,o)&&(e[o]=r[o])}return e}).apply(this,arguments)}function f(e){let{webpackRequire:t,shareScope:r,initScope:o,shareScopeKey:n,remoteEntryInitOptions:i}=e;if(!t.S||!t.federation||!t.federation.instance||!t.federation.initOptions)return;let a=t.federation.instance;a.initOptions(p({name:t.federation.initOptions.name,remotes:[]},i));let s=null==i?void 0:i.shareScopeKeys,l=null==i?void 0:i.shareScopeMap;if(n&&"string"!=typeof n)n.forEach(e=>{if(!s||!l)return void a.initShareScopeMap(e,r,{hostShareScopeMap:(null==i?void 0:i.shareScopeMap)||{}});l[e]||(l[e]={});let t=l[e];a.initShareScopeMap(e,t,{hostShareScopeMap:(null==i?void 0:i.shareScopeMap)||{}})});else{let e=n||"default";Array.isArray(s)?s.forEach(e=>{l[e]||(l[e]={});let t=l[e];a.initShareScopeMap(e,t,{hostShareScopeMap:(null==i?void 0:i.shareScopeMap)||{}})}):a.initShareScopeMap(e,r,{hostShareScopeMap:(null==i?void 0:i.shareScopeMap)||{}})}return(t.federation.attachShareScopeMap&&t.federation.attachShareScopeMap(t),"function"==typeof t.federation.prefetch&&t.federation.prefetch(),Array.isArray(n))?t.federation.initOptions.shared?t.I(n,o):Promise.all(n.map(e=>t.I(e,o))).then(()=>!0):t.I(n||"default",o)}e.exports={runtime:function(e){var t=Object.create(null);if(e)for(var r in e)t[r]=e[r];return t.default=e,Object.freeze(t)}(o),instance:void 0,initOptions:void 0,bundlerRuntime:{remotes:s,consumes:l,I:c,S:{},installInitialConsumes:d,initContainerEntry:f},attachShareScopeMap:a,bundlerRuntimeOptions:{}}},8306(e,t,r){var o=r(6558),n=r(318),i=r(7022);let a="[ Federation Runtime ]",s=n.createLogger(a);function l(e,t){e||c(t)}function c(e){if(e instanceof Error)throw e.message=`${a}: ${e.message}`,e;throw Error(`${a}: ${e}`)}function u(e){e instanceof Error&&(e.message=`${a}: ${e.message}`),s.warn(e)}function d(e,t){return -1===e.findIndex(e=>e===t)&&e.push(t),e}function p(e){return"version"in e&&e.version?`${e.name}:${e.version}`:"entry"in e&&e.entry?`${e.name}:${e.entry}`:`${e.name}`}function f(e){return void 0!==e.entry}function h(e){return!e.entry.includes(".json")&&e.entry.includes(".js")}async function m(e,t){try{return await e()}catch(e){t||u(e);return}}function g(e){return e&&"object"==typeof e}let y=Object.prototype.toString;function _(e){return"[object Object]"===y.call(e)}function b(e,t){let r=/^(https?:)?\/\//i;return e.replace(r,"").replace(/\/$/,"")===t.replace(r,"").replace(/\/$/,"")}function E(e){return Array.isArray(e)?e:[e]}function v(e){let t={url:"",type:"global",globalName:""};return n.isBrowserEnv()||n.isReactNativeEnv()?"remoteEntry"in e?{url:e.remoteEntry,type:e.remoteEntryType,globalName:e.globalName}:t:"ssrRemoteEntry"in e?{url:e.ssrRemoteEntry||t.url,type:e.ssrRemoteEntryType||t.type,globalName:e.globalName}:t}let S=(e,t)=>{let r;return r=e.endsWith("/")?e.slice(0,-1):e,t.startsWith(".")&&(t=t.slice(1)),r+=t},x="object"==typeof globalThis?globalThis:window,$=(()=>{try{return document.defaultView}catch(e){return x}})(),w=$;function T(e,t,r){Object.defineProperty(e,t,{value:r,configurable:!1,writable:!0})}function R(e,t){return Object.hasOwnProperty.call(e,t)}R(x,"__GLOBAL_LOADING_REMOTE_ENTRY__")||T(x,"__GLOBAL_LOADING_REMOTE_ENTRY__",{});let I=x.__GLOBAL_LOADING_REMOTE_ENTRY__;function N(e){var t,r,o,n,i,a,s,l,c,u,d,p;R(e,"__VMOK__")&&!R(e,"__FEDERATION__")&&T(e,"__FEDERATION__",e.__VMOK__),R(e,"__FEDERATION__")||(T(e,"__FEDERATION__",{__GLOBAL_PLUGIN__:[],__INSTANCES__:[],moduleInfo:{},__SHARE__:{},__MANIFEST_LOADING__:{},__PRELOADED_MAP__:new Map}),T(e,"__VMOK__",e.__FEDERATION__)),null!=(s=(t=e.__FEDERATION__).__GLOBAL_PLUGIN__)||(t.__GLOBAL_PLUGIN__=[]),null!=(l=(r=e.__FEDERATION__).__INSTANCES__)||(r.__INSTANCES__=[]),null!=(c=(o=e.__FEDERATION__).moduleInfo)||(o.moduleInfo={}),null!=(u=(n=e.__FEDERATION__).__SHARE__)||(n.__SHARE__={}),null!=(d=(i=e.__FEDERATION__).__MANIFEST_LOADING__)||(i.__MANIFEST_LOADING__={}),null!=(p=(a=e.__FEDERATION__).__PRELOADED_MAP__)||(a.__PRELOADED_MAP__=new Map)}function O(){x.__FEDERATION__.__GLOBAL_PLUGIN__=[],x.__FEDERATION__.__INSTANCES__=[],x.__FEDERATION__.moduleInfo={},x.__FEDERATION__.__SHARE__={},x.__FEDERATION__.__MANIFEST_LOADING__={},Object.keys(I).forEach(e=>{delete I[e]})}function A(e){x.__FEDERATION__.__INSTANCES__.push(e)}function k(){return x.__FEDERATION__.__DEBUG_CONSTRUCTOR__}function M(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:n.isDebugMode();t&&(x.__FEDERATION__.__DEBUG_CONSTRUCTOR__=e,x.__FEDERATION__.__DEBUG_CONSTRUCTOR_VERSION__="0.13.1")}function P(e,t){if("string"==typeof t){if(e[t])return{value:e[t],key:t};for(let r of Object.keys(e)){let[o,n]=r.split(":"),i=`${o}:${t}`,a=e[i];if(a)return{value:a,key:i}}return{value:void 0,key:t}}throw Error("key must be string")}N(x),N($);let D=()=>$.__FEDERATION__.moduleInfo,F=(e,t)=>{let r=P(t,p(e)).value;if(r&&!r.version&&"version"in e&&e.version&&(r.version=e.version),r)return r;if("version"in e&&e.version){let{version:t}=e,r=p(o._object_without_properties_loose(e,["version"])),n=P($.__FEDERATION__.moduleInfo,r).value;if((null==n?void 0:n.version)===t)return n}},j=e=>F(e,$.__FEDERATION__.moduleInfo),L=(e,t)=>{let r=p(e);return $.__FEDERATION__.moduleInfo[r]=t,$.__FEDERATION__.moduleInfo},H=e=>($.__FEDERATION__.moduleInfo=o._extends({},$.__FEDERATION__.moduleInfo,e),()=>{for(let t of Object.keys(e))delete $.__FEDERATION__.moduleInfo[t]}),C=(e,t)=>{let r=t||`__FEDERATION_${e}:custom__`,o=x[r];return{remoteEntryKey:r,entryExports:o}},U=e=>{let{__GLOBAL_PLUGIN__:t}=$.__FEDERATION__;e.forEach(e=>{-1===t.findIndex(t=>t.name===e.name)?t.push(e):u(`The plugin ${e.name} has been registered.`)})},G=()=>$.__FEDERATION__.__GLOBAL_PLUGIN__,B=e=>x.__FEDERATION__.__PRELOADED_MAP__.get(e),V=e=>x.__FEDERATION__.__PRELOADED_MAP__.set(e,!0),z="default",q="global",W="[0-9A-Za-z-]+",K=`(?:\\+(${W}(?:\\.${W})*))`,Y="0|[1-9]\\d*",J="[0-9]+",X="\\d*[a-zA-Z-][a-zA-Z0-9-]*",Z=`(?:${J}|${X})`,Q=`(?:-?(${Z}(?:\\.${Z})*))`,ee=`(?:${Y}|${X})`,et=`(?:-(${ee}(?:\\.${ee})*))`,er=`${Y}|x|X|\\*`,eo=`[v=\\s]*(${er})(?:\\.(${er})(?:\\.(${er})(?:${et})?${K}?)?)?`,en=`^\\s*(${eo})\\s+-\\s+(${eo})\\s*$`,ei=`(${J})\\.(${J})\\.(${J})`,ea=`[v=\\s]*${ei}${Q}?${K}?`,es="((?:<|>)?=?)",el=`(\\s*)${es}\\s*(${ea}|${eo})`,ec="(?:~>?)",eu=`(\\s*)${ec}\\s+`,ed="(?:\\^)",ep=`(\\s*)${ed}\\s+`,ef="(<|>)?=?\\s*\\*",eh=`^${ed}${eo}$`,em=`(${Y})\\.(${Y})\\.(${Y})`,eg=`v?${em}${et}?${K}?`,ey=`^${ec}${eo}$`,e_=`^${es}\\s*${eo}$`,eb=`^${es}\\s*(${eg})$|^$`,eE="^\\s*>=\\s*0.0.0\\s*$";function ev(e){return new RegExp(e)}function eS(e){return!e||"x"===e.toLowerCase()||"*"===e}function ex(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return e=>t.reduce((e,t)=>t(e),e)}function e$(e){return e.match(ev(eb))}function ew(e,t,r,o){let n=`${e}.${t}.${r}`;return o?`${n}-${o}`:n}function eT(e){return e.replace(ev(en),(e,t,r,o,n,i,a,s,l,c,u,d)=>(t=eS(r)?"":eS(o)?`>=${r}.0.0`:eS(n)?`>=${r}.${o}.0`:`>=${t}`,s=eS(l)?"":eS(c)?`<${Number(l)+1}.0.0-0`:eS(u)?`<${l}.${Number(c)+1}.0-0`:d?`<=${l}.${c}.${u}-${d}`:`<=${s}`,`${t} ${s}`.trim()))}function eR(e){return e.replace(ev(el),"$1$2$3")}function eI(e){return e.replace(ev(eu),"$1~")}function eN(e){return e.replace(ev(ep),"$1^")}function eO(e){return e.trim().split(/\s+/).map(e=>e.replace(ev(eh),(e,t,r,o,n)=>{if(eS(t))return"";if(eS(r))return`>=${t}.0.0 <${Number(t)+1}.0.0-0`;if(eS(o))if("0"===t)return`>=${t}.${r}.0 <${t}.${Number(r)+1}.0-0`;else return`>=${t}.${r}.0 <${Number(t)+1}.0.0-0`;if(n)if("0"!==t)return`>=${t}.${r}.${o}-${n} <${Number(t)+1}.0.0-0`;else if("0"===r)return`>=${t}.${r}.${o}-${n} <${t}.${r}.${Number(o)+1}-0`;else return`>=${t}.${r}.${o}-${n} <${t}.${Number(r)+1}.0-0`;if("0"===t)if("0"===r)return`>=${t}.${r}.${o} <${t}.${r}.${Number(o)+1}-0`;else return`>=${t}.${r}.${o} <${t}.${Number(r)+1}.0-0`;return`>=${t}.${r}.${o} <${Number(t)+1}.0.0-0`})).join(" ")}function eA(e){return e.trim().split(/\s+/).map(e=>e.replace(ev(ey),(e,t,r,o,n)=>eS(t)?"":eS(r)?`>=${t}.0.0 <${Number(t)+1}.0.0-0`:eS(o)?`>=${t}.${r}.0 <${t}.${Number(r)+1}.0-0`:n?`>=${t}.${r}.${o}-${n} <${t}.${Number(r)+1}.0-0`:`>=${t}.${r}.${o} <${t}.${Number(r)+1}.0-0`)).join(" ")}function ek(e){return e.split(/\s+/).map(e=>e.trim().replace(ev(e_),(e,t,r,o,n,i)=>{let a=eS(r),s=a||eS(o),l=s||eS(n);if("="===t&&l&&(t=""),i="",a)if(">"===t||"<"===t)return"<0.0.0-0";else return"*";return t&&l?(s&&(o=0),n=0,">"===t?(t=">=",s?(r=Number(r)+1,o=0):o=Number(o)+1,n=0):"<="===t&&(t="<",s?r=Number(r)+1:o=Number(o)+1),"<"===t&&(i="-0"),`${t+r}.${o}.${n}${i}`):s?`>=${r}.0.0${i} <${Number(r)+1}.0.0-0`:l?`>=${r}.${o}.0${i} <${r}.${Number(o)+1}.0-0`:e})).join(" ")}function eM(e){return e.trim().replace(ev(ef),"")}function eP(e){return e.trim().replace(ev(eE),"")}function eD(e,t){return(e=Number(e)||e)>(t=Number(t)||t)?1:e===t?0:-1}function eF(e,t){let{preRelease:r}=e,{preRelease:o}=t;if(void 0===r&&o)return 1;if(r&&void 0===o)return -1;if(void 0===r&&void 0===o)return 0;for(let e=0,t=r.length;e<=t;e++){let t=r[e],n=o[e];if(t!==n){if(void 0===t&&void 0===n)return 0;if(!t)return 1;if(!n)return -1;return eD(t,n)}}return 0}function ej(e,t){return eD(e.major,t.major)||eD(e.minor,t.minor)||eD(e.patch,t.patch)||eF(e,t)}function eL(e,t){return e.version===t.version}function eH(e,t){switch(e.operator){case"":case"=":return eL(e,t);case">":return 0>ej(e,t);case">=":return eL(e,t)||0>ej(e,t);case"<":return ej(e,t)>0;case"<=":return eL(e,t)||ej(e,t)>0;case void 0:return!0;default:return!1}}function eC(e){return ex(eO,eA,ek,eM)(e)}function eU(e){return ex(eT,eR,eI,eN)(e.trim()).split(/\s+/).join(" ")}function eG(e,t){if(!e)return!1;let r=eU(t).split(" ").map(e=>eC(e)).join(" ").split(/\s+/).map(e=>eP(e)),o=e$(e);if(!o)return!1;let[,n,,i,a,s,l]=o,c={operator:n,version:ew(i,a,s,l),major:i,minor:a,patch:s,preRelease:null==l?void 0:l.split(".")};for(let e of r){let t=e$(e);if(!t)return!1;let[,r,,o,n,i,a]=t;if(!eH({operator:r,version:ew(o,n,i,a),major:o,minor:n,patch:i,preRelease:null==a?void 0:a.split(".")},c))return!1}return!0}function eB(e,t,r,n){var i,a,s;let l;return l="get"in e?e.get:"lib"in e?()=>Promise.resolve(e.lib):()=>Promise.resolve(()=>{throw Error(`Can not get shared '${r}'!`)}),o._extends({deps:[],useIn:[],from:t,loading:null},e,{shareConfig:o._extends({requiredVersion:`^${e.version}`,singleton:!1,eager:!1,strictVersion:!1},e.shareConfig),get:l,loaded:null!=e&&!!e.loaded||"lib"in e||void 0,version:null!=(i=e.version)?i:"0",scope:Array.isArray(e.scope)?e.scope:[null!=(a=e.scope)?a:"default"],strategy:(null!=(s=e.strategy)?s:n)||"version-first"})}function eV(e,t){let r=t.shared||{},n=t.name,i=Object.keys(r).reduce((e,o)=>{let i=E(r[o]);return e[o]=e[o]||[],i.forEach(r=>{e[o].push(eB(r,n,o,t.shareStrategy))}),e},{}),a=o._extends({},e.shared);return Object.keys(i).forEach(e=>{a[e]?i[e].forEach(t=>{a[e].find(e=>e.version===t.version)||a[e].push(t)}):a[e]=i[e]}),{shared:a,shareInfos:i}}function ez(e,t){let r=e=>{if(!Number.isNaN(Number(e))){let t=e.split("."),r=e;for(let e=0;e<3-t.length;e++)r+=".0";return r}return e};return!!eG(r(e),`<=${r(t)}`)}let eq=(e,t)=>{let r=t||function(e,t){return ez(e,t)};return Object.keys(e).reduce((e,t)=>!e||r(e,t)||"0"===e?t:e,0)},eW=e=>!!e.loaded||"function"==typeof e.lib,eK=e=>!!e.loading;function eY(e,t,r){let o=e[t][r],n=function(e,t){return!eW(o[e])&&ez(e,t)};return eq(e[t][r],n)}function eJ(e,t,r){let o=e[t][r],n=function(e,t){let r=e=>eW(e)||eK(e);if(r(o[t]))if(r(o[e]))return!!ez(e,t);else return!0;return!r(o[e])&&ez(e,t)};return eq(e[t][r],n)}function eX(e){return"loaded-first"===e?eJ:eY}function eZ(e,t,r,o){if(!e)return;let{shareConfig:n,scope:i=z,strategy:a}=r;for(let s of Array.isArray(i)?i:[i])if(n&&e[s]&&e[s][t]){let{requiredVersion:i}=n,l=eX(a)(e,s,t),d=()=>{if(n.singleton){if("string"==typeof i&&!eG(l,i)){let o=`Version ${l} from ${l&&e[s][t][l].from} of shared singleton module ${t} does not satisfy the requirement of ${r.from} which needs ${i})`;n.strictVersion?c(o):u(o)}return e[s][t][l]}if(!1===i||"*"===i||eG(l,i))return e[s][t][l];for(let[r,o]of Object.entries(e[s][t]))if(eG(r,i))return o},p={shareScopeMap:e,scope:s,pkgName:t,version:l,GlobalFederation:w.__FEDERATION__,resolver:d};return(o.emit(p)||p).resolver()}}function eQ(){return w.__FEDERATION__.__SHARE__}function e0(e){var t;let{pkgName:r,extraOptions:o,shareInfos:n}=e,i=e=>{if(!e)return;let t={};e.forEach(e=>{t[e.version]=e});let r=function(e,r){return!eW(t[e])&&ez(e,r)},o=eq(t,r);return t[o]};return Object.assign({},(null!=(t=null==o?void 0:o.resolver)?t:i)(n[r]),null==o?void 0:o.customShareInfo)}var e1={global:{Global:w,nativeGlobal:$,resetFederationGlobalInfo:O,setGlobalFederationInstance:A,getGlobalFederationConstructor:k,setGlobalFederationConstructor:M,getInfoWithoutType:P,getGlobalSnapshot:D,getTargetSnapshotInfoByModuleInfo:F,getGlobalSnapshotInfoByModuleInfo:j,setGlobalSnapshotInfoByModuleInfo:L,addGlobalSnapshot:H,getRemoteEntryExports:C,registerGlobalPlugins:U,getGlobalHostPlugins:G,getPreloaded:B,setPreloaded:V},share:{getRegisteredShare:eZ,getGlobalShareScope:eQ}};function e2(){return"datadefinitions:1.0.0"}function e8(e,t){for(let r of e){let e=t.startsWith(r.name),o=t.replace(r.name,"");if(e){if(o.startsWith("/"))return{pkgNameOrAlias:r.name,expose:o=`.${o}`,remote:r};else if(""===o)return{pkgNameOrAlias:r.name,expose:".",remote:r}}let n=r.alias&&t.startsWith(r.alias),i=r.alias&&t.replace(r.alias,"");if(r.alias&&n){if(i&&i.startsWith("/"))return{pkgNameOrAlias:r.alias,expose:i=`.${i}`,remote:r};else if(""===i)return{pkgNameOrAlias:r.alias,expose:".",remote:r}}}}function e5(e,t){for(let r of e)if(t===r.name||r.alias&&t===r.alias)return r}function e6(e,t){let r=G();return r.length>0&&r.forEach(t=>{(null==e?void 0:e.find(e=>e.name!==t.name))&&e.push(t)}),e&&e.length>0&&e.forEach(e=>{t.forEach(t=>{t.applyPlugin(e)})}),e}async function e4(e){let{entry:t,remoteEntryExports:r}=e;return new Promise((e,o)=>{try{r?e(r):"u">typeof FEDERATION_ALLOW_NEW_FUNCTION?Function("callbacks",`import("${t}").then(callbacks[0]).catch(callbacks[1])`)([e,o]):import(t).then(e).catch(o)}catch(e){o(e)}})}async function e9(e){let{entry:t,remoteEntryExports:r}=e;return new Promise((e,o)=>{try{r?e(r):Function("callbacks",`System.import("${t}").then(callbacks[0]).catch(callbacks[1])`)([e,o])}catch(e){o(e)}})}async function e3(e){let{name:t,globalName:r,entry:o,loaderHook:a}=e,{entryExports:s}=C(t,r);return s||n.loadScript(o,{attrs:{},createScriptHook:(e,t)=>{let r=a.lifecycle.createScript.emit({url:e,attrs:t});if(r&&(r instanceof HTMLScriptElement||"script"in r||"timeout"in r))return r}}).then(()=>{let{remoteEntryKey:e,entryExports:n}=C(t,r);return l(n,i.getShortErrorMsg(i.RUNTIME_001,i.runtimeDescMap,{remoteName:t,remoteEntryUrl:o,remoteEntryKey:e})),n}).catch(e=>{throw l(void 0,i.getShortErrorMsg(i.RUNTIME_008,i.runtimeDescMap,{remoteName:t,resourceUrl:o})),e})}async function e7(e){let{remoteInfo:t,remoteEntryExports:r,loaderHook:o}=e,{entry:n,entryGlobalName:i,name:a,type:s}=t;switch(s){case"esm":case"module":return e4({entry:n,remoteEntryExports:r});case"system":return e9({entry:n,remoteEntryExports:r});default:return e3({entry:n,globalName:i,name:a,loaderHook:o})}}async function te(e){let{remoteInfo:t,loaderHook:r}=e,{entry:o,entryGlobalName:a,name:s,type:c}=t,{entryExports:u}=C(s,a);return u||n.loadScriptNode(o,{attrs:{name:s,globalName:a,type:c},loaderHook:{createScriptHook:function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},o=r.lifecycle.createScript.emit({url:e,attrs:t});if(o&&"url"in o)return o}}}).then(()=>{let{remoteEntryKey:e,entryExports:t}=C(s,a);return l(t,i.getShortErrorMsg(i.RUNTIME_001,i.runtimeDescMap,{remoteName:s,remoteEntryUrl:o,remoteEntryKey:e})),t}).catch(e=>{throw e})}function tt(e){let{entry:t,name:r}=e;return n.composeKeyWithSeparator(r,t)}async function tr(e){let{origin:t,remoteEntryExports:r,remoteInfo:o}=e,i=tt(o);if(r)return r;if(!I[i]){let e=t.remoteHandler.hooks.lifecycle.loadEntry,a=t.loaderHook;I[i]=e.emit({loaderHook:a,remoteInfo:o,remoteEntryExports:r}).then(e=>e||(n.isBrowserEnv()?e7({remoteInfo:o,remoteEntryExports:r,loaderHook:a}):te({remoteInfo:o,loaderHook:a})))}return I[i]}function to(e){return o._extends({},e,{entry:"entry"in e?e.entry:"",type:e.type||q,entryGlobalName:e.entryGlobalName||e.name,shareScope:e.shareScope||z})}let tn=class{async getEntry(){let e;if(this.remoteEntryExports)return this.remoteEntryExports;try{e=await tr({origin:this.host,remoteInfo:this.remoteInfo,remoteEntryExports:this.remoteEntryExports})}catch(r){let t=tt(this.remoteInfo);e=await this.host.loaderHook.lifecycle.loadEntryError.emit({getRemoteEntry:tr,origin:this.host,remoteInfo:this.remoteInfo,remoteEntryExports:this.remoteEntryExports,globalLoading:I,uniqueKey:t})}return l(e,`remoteEntryExports is undefined 
 ${n.safeToString(this.remoteInfo)}`),this.remoteEntryExports=e,this.remoteEntryExports}async get(e,t,r,n){let a,{loadFactory:s=!0}=r||{loadFactory:!0},u=await this.getEntry();if(!this.inited){let t=this.host.shareScopeMap,r=Array.isArray(this.remoteInfo.shareScope)?this.remoteInfo.shareScope:[this.remoteInfo.shareScope];r.length||r.push("default"),r.forEach(e=>{t[e]||(t[e]={})});let a=t[r[0]],s=[],l={version:this.remoteInfo.version||"",shareScopeKeys:Array.isArray(this.remoteInfo.shareScope)?r:this.remoteInfo.shareScope||"default"};Object.defineProperty(l,"shareScopeMap",{value:t,enumerable:!1});let d=await this.host.hooks.lifecycle.beforeInitContainer.emit({shareScope:a,remoteEntryInitOptions:l,initScope:s,remoteInfo:this.remoteInfo,origin:this.host});void 0===(null==u?void 0:u.init)&&c(i.getShortErrorMsg(i.RUNTIME_002,i.runtimeDescMap,{remoteName:name,remoteEntryUrl:this.remoteInfo.entry,remoteEntryKey:this.remoteInfo.entryGlobalName})),await u.init(d.shareScope,d.initScope,d.remoteEntryInitOptions),await this.host.hooks.lifecycle.initContainer.emit(o._extends({},d,{id:e,remoteSnapshot:n,remoteEntryExports:u}))}this.lib=u,this.inited=!0,(a=await this.host.loaderHook.lifecycle.getModuleFactory.emit({remoteEntryExports:u,expose:t,moduleInfo:this.remoteInfo}))||(a=await u.get(t)),l(a,`${p(this.remoteInfo)} remote don't export ${t}.`);let d=S(this.remoteInfo.name,t),f=this.wraperFactory(a,d);return s?await f():f}wraperFactory(e,t){function r(e,t){e&&"object"==typeof e&&Object.isExtensible(e)&&!Object.getOwnPropertyDescriptor(e,Symbol.for("mf_module_id"))&&Object.defineProperty(e,Symbol.for("mf_module_id"),{value:t,enumerable:!1})}return e instanceof Promise?async()=>{let o=await e();return r(o,t),o}:()=>{let o=e();return r(o,t),o}}constructor({remoteInfo:e,host:t}){this.inited=!1,this.lib=void 0,this.remoteInfo=e,this.host=t}};class ti{on(e){"function"==typeof e&&this.listeners.add(e)}once(e){let t=this;this.on(function r(){for(var o=arguments.length,n=Array(o),i=0;i<o;i++)n[i]=arguments[i];return t.remove(r),e.apply(null,n)})}emit(){let e;for(var t=arguments.length,r=Array(t),o=0;o<t;o++)r[o]=arguments[o];return this.listeners.size>0&&this.listeners.forEach(t=>{e=t(...r)}),e}remove(e){this.listeners.delete(e)}removeAll(){this.listeners.clear()}constructor(e){this.type="",this.listeners=new Set,e&&(this.type=e)}}class ta extends ti{emit(){let e;for(var t=arguments.length,r=Array(t),o=0;o<t;o++)r[o]=arguments[o];let n=Array.from(this.listeners);if(n.length>0){let t=0,o=e=>!1!==e&&(t<n.length?Promise.resolve(n[t++].apply(null,r)).then(o):e);e=o()}return Promise.resolve(e)}}function ts(e,t){if(!g(t))return!1;if(e!==t){for(let r in e)if(!(r in t))return!1}return!0}class tl extends ti{emit(e){for(let t of(g(e)||c(`The data for the "${this.type}" hook should be an object.`),this.listeners))try{let r=t(e);if(ts(e,r))e=r;else{this.onerror(`A plugin returned an unacceptable value for the "${this.type}" type.`);break}}catch(e){u(e),this.onerror(e)}return e}constructor(e){super(),this.onerror=c,this.type=e}}class tc extends ti{emit(e){g(e)||c(`The response data for the "${this.type}" hook must be an object.`);let t=Array.from(this.listeners);if(t.length>0){let r=0,o=t=>(u(t),this.onerror(t),e),n=i=>{if(ts(e,i)){if(e=i,r<t.length)try{return Promise.resolve(t[r++](e)).then(n,o)}catch(e){return o(e)}}else this.onerror(`A plugin returned an incorrect value for the "${this.type}" type.`);return e};return Promise.resolve(n(e))}return Promise.resolve(e)}constructor(e){super(),this.onerror=c,this.type=e}}class tu{applyPlugin(e){l(_(e),"Plugin configuration is invalid.");let t=e.name;l(t,"A name must be provided by the plugin."),this.registerPlugins[t]||(this.registerPlugins[t]=e,Object.keys(this.lifecycle).forEach(t=>{let r=e[t];r&&this.lifecycle[t].on(r)}))}removePlugin(e){l(e,"A name is required.");let t=this.registerPlugins[e];l(t,`The plugin "${e}" is not registered.`),Object.keys(t).forEach(e=>{"name"!==e&&this.lifecycle[e].remove(t[e])})}inherit(e){let{lifecycle:t,registerPlugins:r}=e;Object.keys(t).forEach(e=>{l(!this.lifecycle[e],`The hook "${e}" has a conflict and cannot be inherited.`),this.lifecycle[e]=t[e]}),Object.keys(r).forEach(e=>{l(!this.registerPlugins[e],`The plugin "${e}" has a conflict and cannot be inherited.`),this.applyPlugin(r[e])})}constructor(e){this.registerPlugins={},this.lifecycle=e,this.lifecycleKeys=Object.keys(e)}}function td(e){return o._extends({resourceCategory:"sync",share:!0,depsRemote:!0,prefetchInterface:!1},e)}function tp(e,t){return t.map(t=>{let r=e5(e,t.nameOrAlias);return l(r,`Unable to preload ${t.nameOrAlias} as it is not included in ${!r&&n.safeToString({remoteInfo:r,remotes:e})}`),{remote:r,preloadConfig:td(t)}})}function tf(e){return e?e.map(e=>"."===e?e:e.startsWith("./")?e.replace("./",""):e):[]}function th(e,t,r){let o=!(arguments.length>3)||void 0===arguments[3]||arguments[3],{cssAssets:i,jsAssetsWithoutEntry:a,entryAssets:s}=r;if(t.options.inBrowser){if(s.forEach(r=>{let{moduleInfo:o}=r,n=t.moduleCache.get(e.name);n?tr({origin:t,remoteInfo:o,remoteEntryExports:n.remoteEntryExports}):tr({origin:t,remoteInfo:o,remoteEntryExports:void 0})}),o){let e={rel:"preload",as:"style"};i.forEach(r=>{let{link:o,needAttach:i}=n.createLink({url:r,cb:()=>{},attrs:e,createLinkHook:(e,r)=>{let o=t.loaderHook.lifecycle.createLink.emit({url:e,attrs:r});if(o instanceof HTMLLinkElement)return o}});i&&document.head.appendChild(o)})}else{let e={rel:"stylesheet",type:"text/css"};i.forEach(r=>{let{link:o,needAttach:i}=n.createLink({url:r,cb:()=>{},attrs:e,createLinkHook:(e,r)=>{let o=t.loaderHook.lifecycle.createLink.emit({url:e,attrs:r});if(o instanceof HTMLLinkElement)return o},needDeleteLink:!1});i&&document.head.appendChild(o)})}if(o){let e={rel:"preload",as:"script"};a.forEach(r=>{let{link:o,needAttach:i}=n.createLink({url:r,cb:()=>{},attrs:e,createLinkHook:(e,r)=>{let o=t.loaderHook.lifecycle.createLink.emit({url:e,attrs:r});if(o instanceof HTMLLinkElement)return o}});i&&document.head.appendChild(o)})}else{let r={fetchpriority:"high",type:(null==e?void 0:e.type)==="module"?"module":"text/javascript"};a.forEach(e=>{let{script:o,needAttach:i}=n.createScript({url:e,cb:()=>{},attrs:r,createScriptHook:(e,r)=>{let o=t.loaderHook.lifecycle.createScript.emit({url:e,attrs:r});if(o instanceof HTMLScriptElement)return o},needDeleteScript:!0});i&&document.head.appendChild(o)})}}}function tm(e,t){let r=v(t);r.url||c(`The attribute remoteEntry of ${e.name} must not be undefined.`);let o=n.getResourceUrl(t,r.url);n.isBrowserEnv()||o.startsWith("http")||(o=`https:${o}`),e.type=r.type,e.entryGlobalName=r.globalName,e.entry=o,e.version=t.version,e.buildVersion=t.buildVersion}function tg(){return{name:"snapshot-plugin",async afterResolve(e){let{remote:t,pkgNameOrAlias:r,expose:n,origin:i,remoteInfo:a}=e;if(!f(t)||!h(t)){let{remoteSnapshot:s,globalSnapshot:l}=await i.snapshotHandler.loadRemoteSnapshotInfo(t);tm(a,s);let c={remote:t,preloadConfig:{nameOrAlias:r,exposes:[n],resourceCategory:"sync",share:!1,depsRemote:!1}},u=await i.remoteHandler.hooks.lifecycle.generatePreloadAssets.emit({origin:i,preloadOptions:c,remoteInfo:a,remote:t,remoteSnapshot:s,globalSnapshot:l});return u&&th(a,i,u,!1),o._extends({},e,{remoteSnapshot:s})}return e}}}function ty(e){let t=e.split(":");return 1===t.length?{name:t[0],version:void 0}:2===t.length?{name:t[0],version:t[1]}:{name:t[1],version:t[2]}}function t_(e,t,r,o){let i=arguments.length>4&&void 0!==arguments[4]?arguments[4]:{},a=arguments.length>5?arguments[5]:void 0,{value:s}=P(e,p(t)),l=a||s;if(l&&!n.isManifestProvider(l)&&(r(l,t,o),l.remotesInfo))for(let t of Object.keys(l.remotesInfo)){if(i[t])continue;i[t]=!0;let o=ty(t),n=l.remotesInfo[t];t_(e,{name:o.name,version:n.matchedVersion},r,!1,i,void 0)}}let tb=(e,t)=>document.querySelector(`${e}[${"link"===e?"href":"src"}="${t}"]`);function tE(e,t,r,o,i){let a=[],s=[],l=[],c=new Set,u=new Set,{options:d}=e,{preloadConfig:p}=t,{depsRemote:f}=p;if(t_(o,r,(t,r,o)=>{let i;if(o)i=p;else if(Array.isArray(f)){let e=f.find(e=>e.nameOrAlias===r.name||e.nameOrAlias===r.alias);if(!e)return;i=td(e)}else{if(!0!==f)return;i=p}let c=n.getResourceUrl(t,v(t).url);c&&l.push({name:r.name,moduleInfo:{name:r.name,entry:c,type:"remoteEntryType"in t?t.remoteEntryType:"global",entryGlobalName:"globalName"in t?t.globalName:r.name,shareScope:"",version:"version"in t?t.version:void 0},url:c});let u="modules"in t?t.modules:[],d=tf(i.exposes);if(d.length&&"modules"in t){var h;u=null==t||null==(h=t.modules)?void 0:h.reduce((e,t)=>((null==d?void 0:d.indexOf(t.moduleName))!==-1&&e.push(t),e),[])}function m(e){let r=e.map(e=>n.getResourceUrl(t,e));return i.filter?r.filter(i.filter):r}if(u){let o=u.length;for(let n=0;n<o;n++){let o=u[n],l=`${r.name}/${o.moduleName}`;e.remoteHandler.hooks.lifecycle.handlePreloadModule.emit({id:"."===o.moduleName?r.name:l,name:r.name,remoteSnapshot:t,preloadConfig:i,remote:r,origin:e}),B(l)||("all"===i.resourceCategory?(a.push(...m(o.assets.css.async)),a.push(...m(o.assets.css.sync)),s.push(...m(o.assets.js.async))):(i.resourceCategory="sync",a.push(...m(o.assets.css.sync))),s.push(...m(o.assets.js.sync)),V(l))}}},!0,{},i),i.shared){let t=(t,r)=>{let o=eZ(e.shareScopeMap,r.sharedName,t,e.sharedHandler.hooks.lifecycle.resolveShare);o&&"function"==typeof o.lib&&(r.assets.js.sync.forEach(e=>{c.add(e)}),r.assets.css.sync.forEach(e=>{u.add(e)}))};i.shared.forEach(e=>{var r;let o=null==(r=d.shared)?void 0:r[e.sharedName];if(!o)return;let n=e.version?o.find(t=>t.version===e.version):o;n&&E(n).forEach(r=>{t(r,e)})})}let h=s.filter(e=>!c.has(e)&&!tb("script",e));return{cssAssets:a.filter(e=>!u.has(e)&&!tb("link",e)),jsAssetsWithoutEntry:h,entryAssets:l.filter(e=>!tb("script",e.url))}}let tv=function(){return{name:"generate-preload-assets-plugin",async generatePreloadAssets(e){let{origin:t,preloadOptions:r,remoteInfo:o,remote:i,globalSnapshot:a,remoteSnapshot:s}=e;return n.isBrowserEnv()?f(i)&&h(i)?{cssAssets:[],jsAssetsWithoutEntry:[],entryAssets:[{name:i.name,url:i.entry,moduleInfo:{name:o.name,entry:i.entry,type:o.type||"global",entryGlobalName:"",shareScope:""}}]}:(tm(o,s),tE(t,r,o,a,s)):{cssAssets:[],jsAssetsWithoutEntry:[],entryAssets:[]}}}};function tS(e,t){let r=j({name:t.options.name,version:t.options.version}),o=r&&"remotesInfo"in r&&r.remotesInfo&&P(r.remotesInfo,e.name).value;return o&&o.matchedVersion?{hostGlobalSnapshot:r,globalSnapshot:D(),remoteSnapshot:j({name:e.name,version:o.matchedVersion})}:{hostGlobalSnapshot:void 0,globalSnapshot:D(),remoteSnapshot:j({name:e.name,version:"version"in e?e.version:void 0})}}class tx{async loadSnapshot(e){let{options:t}=this.HostInstance,{hostGlobalSnapshot:r,remoteSnapshot:o,globalSnapshot:n}=this.getGlobalRemoteInfo(e),{remoteSnapshot:i,globalSnapshot:a}=await this.hooks.lifecycle.loadSnapshot.emit({options:t,moduleInfo:e,hostGlobalSnapshot:r,remoteSnapshot:o,globalSnapshot:n});return{remoteSnapshot:i,globalSnapshot:a}}async loadRemoteSnapshotInfo(e){let t,r,{options:a}=this.HostInstance;await this.hooks.lifecycle.beforeLoadRemoteSnapshot.emit({options:a,moduleInfo:e});let s=j({name:this.HostInstance.options.name,version:this.HostInstance.options.version});s||(s={version:this.HostInstance.options.version||"",remoteEntry:"",remotesInfo:{}},H({[this.HostInstance.options.name]:s})),s&&"remotesInfo"in s&&!P(s.remotesInfo,e.name).value&&("version"in e||"entry"in e)&&(s.remotesInfo=o._extends({},null==s?void 0:s.remotesInfo,{[e.name]:{matchedVersion:"version"in e?e.version:e.entry}}));let{hostGlobalSnapshot:l,remoteSnapshot:u,globalSnapshot:d}=this.getGlobalRemoteInfo(e),{remoteSnapshot:p,globalSnapshot:h}=await this.hooks.lifecycle.loadSnapshot.emit({options:a,moduleInfo:e,hostGlobalSnapshot:l,remoteSnapshot:u,globalSnapshot:d});if(p)if(n.isManifestProvider(p)){let i=n.isBrowserEnv()?p.remoteEntry:p.ssrRemoteEntry||p.remoteEntry||"",a=await this.getManifestJson(i,e,{}),s=L(o._extends({},e,{entry:i}),a);t=a,r=s}else{let{remoteSnapshot:o}=await this.hooks.lifecycle.loadRemoteSnapshot.emit({options:this.HostInstance.options,moduleInfo:e,remoteSnapshot:p,from:"global"});t=o,r=h}else if(f(e)){let o=await this.getManifestJson(e.entry,e,{}),n=L(e,o),{remoteSnapshot:i}=await this.hooks.lifecycle.loadRemoteSnapshot.emit({options:this.HostInstance.options,moduleInfo:e,remoteSnapshot:o,from:"global"});t=i,r=n}else c(i.getShortErrorMsg(i.RUNTIME_007,i.runtimeDescMap,{hostName:e.name,hostVersion:e.version,globalSnapshot:JSON.stringify(h)}));return await this.hooks.lifecycle.afterLoadSnapshot.emit({options:a,moduleInfo:e,remoteSnapshot:t}),{remoteSnapshot:t,globalSnapshot:r}}getGlobalRemoteInfo(e){return tS(e,this.HostInstance)}async getManifestJson(e,t,r){let o=async()=>{let r=this.manifestCache.get(e);if(r)return r;try{let t=await this.loaderHook.lifecycle.fetch.emit(e,{});t&&t instanceof Response||(t=await fetch(e,{})),r=await t.json()}catch(o){(r=await this.HostInstance.remoteHandler.hooks.lifecycle.errorLoadRemote.emit({id:e,error:o,from:"runtime",lifecycle:"afterResolve",origin:this.HostInstance}))||(delete this.manifestLoading[e],c(i.getShortErrorMsg(i.RUNTIME_003,i.runtimeDescMap,{manifestUrl:e,moduleName:t.name,hostName:this.HostInstance.options.name},`${o}`)))}return l(r.metaData&&r.exposes&&r.shared,`${e} is not a federation manifest`),this.manifestCache.set(e,r),r},a=async()=>{let r=await o(),i=n.generateSnapshotFromManifest(r,{version:e}),{remoteSnapshot:a}=await this.hooks.lifecycle.loadRemoteSnapshot.emit({options:this.HostInstance.options,moduleInfo:t,manifestJson:r,remoteSnapshot:i,manifestUrl:e,from:"manifest"});return a};return this.manifestLoading[e]||(this.manifestLoading[e]=a().then(e=>e)),this.manifestLoading[e]}constructor(e){this.loadingHostSnapshot=null,this.manifestCache=new Map,this.hooks=new tu({beforeLoadRemoteSnapshot:new ta("beforeLoadRemoteSnapshot"),loadSnapshot:new tc("loadGlobalSnapshot"),loadRemoteSnapshot:new tc("loadRemoteSnapshot"),afterLoadSnapshot:new tc("afterLoadSnapshot")}),this.manifestLoading=w.__FEDERATION__.__MANIFEST_LOADING__,this.HostInstance=e,this.loaderHook=e.loaderHook}}class t${registerShared(e,t){let{shareInfos:r,shared:o}=eV(e,t);return Object.keys(r).forEach(e=>{r[e].forEach(r=>{!eZ(this.shareScopeMap,e,r,this.hooks.lifecycle.resolveShare)&&r&&r.lib&&this.setShared({pkgName:e,lib:r.lib,get:r.get,loaded:!0,shared:r,from:t.name})})}),{shareInfos:r,shared:o}}async loadShare(e,t){let{host:r}=this,o=e0({pkgName:e,extraOptions:t,shareInfos:r.options.shared});(null==o?void 0:o.scope)&&await Promise.all(o.scope.map(async e=>{await Promise.all(this.initializeSharing(e,{strategy:o.strategy}))}));let{shareInfo:n}=await this.hooks.lifecycle.beforeLoadShare.emit({pkgName:e,shareInfo:o,shared:r.options.shared,origin:r});l(n,`Cannot find ${e} Share in the ${r.options.name}. Please ensure that the ${e} Share parameters have been injected`);let i=eZ(this.shareScopeMap,e,n,this.hooks.lifecycle.resolveShare),a=e=>{e.useIn||(e.useIn=[]),d(e.useIn,r.options.name)};if(i&&i.lib)return a(i),i.lib;if(i&&i.loading&&!i.loaded){let e=await i.loading;return i.loaded=!0,i.lib||(i.lib=e),a(i),e}if(i){let t=(async()=>{let t=await i.get();n.lib=t,n.loaded=!0,a(n);let r=eZ(this.shareScopeMap,e,n,this.hooks.lifecycle.resolveShare);return r&&(r.lib=t,r.loaded=!0),t})();return this.setShared({pkgName:e,loaded:!1,shared:i,from:r.options.name,lib:null,loading:t}),t}{if(null==t?void 0:t.customShareInfo)return!1;let o=(async()=>{let t=await n.get();n.lib=t,n.loaded=!0,a(n);let r=eZ(this.shareScopeMap,e,n,this.hooks.lifecycle.resolveShare);return r&&(r.lib=t,r.loaded=!0),t})();return this.setShared({pkgName:e,loaded:!1,shared:n,from:r.options.name,lib:null,loading:o}),o}}initializeSharing(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:z,t=arguments.length>1?arguments[1]:void 0,{host:r}=this,o=null==t?void 0:t.from,n=null==t?void 0:t.strategy,i=null==t?void 0:t.initScope,a=[];if("build"!==o){let{initTokens:t}=this;i||(i=[]);let r=t[e];if(r||(r=t[e]={from:this.host.name}),i.indexOf(r)>=0)return a;i.push(r)}let s=this.shareScopeMap,l=r.options.name;s[e]||(s[e]={});let c=s[e],u=(e,t)=>{var r;let{version:o,eager:n}=t;c[e]=c[e]||{};let i=c[e],a=i[o],s=!!(a&&(a.eager||(null==(r=a.shareConfig)?void 0:r.eager)));(!a||"loaded-first"!==a.strategy&&!a.loaded&&(!n!=!s?n:l>a.from))&&(i[o]=t)},d=t=>t&&t.init&&t.init(s[e],i),p=async e=>{let{module:t}=await r.remoteHandler.getRemoteModuleAndOptions({id:e});if(t.getEntry){let o;try{o=await t.getEntry()}catch(t){o=await r.remoteHandler.hooks.lifecycle.errorLoadRemote.emit({id:e,error:t,from:"runtime",lifecycle:"beforeLoadShare",origin:r})}t.inited||(await d(o),t.inited=!0)}};return Object.keys(r.options.shared).forEach(t=>{r.options.shared[t].forEach(r=>{r.scope.includes(e)&&u(t,r)})}),("version-first"===r.options.shareStrategy||"version-first"===n)&&r.options.remotes.forEach(t=>{t.shareScope===e&&a.push(p(t.name))}),a}loadShareSync(e,t){let{host:r}=this,o=e0({pkgName:e,extraOptions:t,shareInfos:r.options.shared});(null==o?void 0:o.scope)&&o.scope.forEach(e=>{this.initializeSharing(e,{strategy:o.strategy})});let n=eZ(this.shareScopeMap,e,o,this.hooks.lifecycle.resolveShare),a=e=>{e.useIn||(e.useIn=[]),d(e.useIn,r.options.name)};if(n){if("function"==typeof n.lib)return a(n),n.loaded||(n.loaded=!0,n.from===r.options.name&&(o.loaded=!0)),n.lib;if("function"==typeof n.get){let t=n.get();if(!(t instanceof Promise))return a(n),this.setShared({pkgName:e,loaded:!0,from:r.options.name,lib:t,shared:n}),t}}if(o.lib)return o.loaded||(o.loaded=!0),o.lib;if(o.get){let n=o.get();if(n instanceof Promise){let o=(null==t?void 0:t.from)==="build"?i.RUNTIME_005:i.RUNTIME_006;throw Error(i.getShortErrorMsg(o,i.runtimeDescMap,{hostName:r.options.name,sharedPkgName:e}))}return o.lib=n,this.setShared({pkgName:e,loaded:!0,from:r.options.name,lib:o.lib,shared:o}),o.lib}throw Error(i.getShortErrorMsg(i.RUNTIME_006,i.runtimeDescMap,{hostName:r.options.name,sharedPkgName:e}))}initShareScopeMap(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{},{host:o}=this;this.shareScopeMap[e]=t,this.hooks.lifecycle.initContainerShareScopeMap.emit({shareScope:t,options:o.options,origin:o,scopeName:e,hostShareScopeMap:r.hostShareScopeMap})}setShared(e){let{pkgName:t,shared:r,from:n,lib:i,loading:a,loaded:s,get:l}=e,{version:c,scope:u="default"}=r,d=o._object_without_properties_loose(r,["version","scope"]);(Array.isArray(u)?u:[u]).forEach(e=>{if(this.shareScopeMap[e]||(this.shareScopeMap[e]={}),this.shareScopeMap[e][t]||(this.shareScopeMap[e][t]={}),!this.shareScopeMap[e][t][c]){this.shareScopeMap[e][t][c]=o._extends({version:c,scope:["default"]},d,{lib:i,loaded:s,loading:a}),l&&(this.shareScopeMap[e][t][c].get=l);return}let r=this.shareScopeMap[e][t][c];a&&!r.loading&&(r.loading=a)})}_setGlobalShareScopeMap(e){let t=eQ(),r=e.id||e.name;r&&!t[r]&&(t[r]=this.shareScopeMap)}constructor(e){this.hooks=new tu({afterResolve:new tc("afterResolve"),beforeLoadShare:new tc("beforeLoadShare"),loadShare:new ta,resolveShare:new tl("resolveShare"),initContainerShareScopeMap:new tl("initContainerShareScopeMap")}),this.host=e,this.shareScopeMap={},this.initTokens={},this._setGlobalShareScopeMap(e.options)}}class tw{formatAndRegisterRemote(e,t){return(t.remotes||[]).reduce((e,t)=>(this.registerRemote(t,e,{force:!1}),e),e.remotes)}setIdToRemoteMap(e,t){let{remote:r,expose:o}=t,{name:n,alias:i}=r;if(this.idToRemoteMap[e]={name:r.name,expose:o},i&&e.startsWith(n)){let t=e.replace(n,i);this.idToRemoteMap[t]={name:r.name,expose:o};return}if(i&&e.startsWith(i)){let t=e.replace(i,n);this.idToRemoteMap[t]={name:r.name,expose:o}}}async loadRemote(e,t){let{host:r}=this;try{let{loadFactory:o=!0}=t||{loadFactory:!0},{module:n,moduleOptions:i,remoteMatchInfo:a}=await this.getRemoteModuleAndOptions({id:e}),{pkgNameOrAlias:s,remote:l,expose:c,id:u,remoteSnapshot:d}=a,p=await n.get(u,c,t,d),f=await this.hooks.lifecycle.onLoad.emit({id:u,pkgNameOrAlias:s,expose:c,exposeModule:o?p:void 0,exposeModuleFactory:o?void 0:p,remote:l,options:i,moduleInstance:n,origin:r});if(this.setIdToRemoteMap(e,a),"function"==typeof f)return f;return p}catch(i){let{from:o="runtime"}=t||{from:"runtime"},n=await this.hooks.lifecycle.errorLoadRemote.emit({id:e,error:i,from:o,lifecycle:"onLoad",origin:r});if(!n)throw i;return n}}async preloadRemote(e){let{host:t}=this;await this.hooks.lifecycle.beforePreloadRemote.emit({preloadOps:e,options:t.options,origin:t});let r=tp(t.options.remotes,e);await Promise.all(r.map(async e=>{let{remote:r}=e,o=to(r),{globalSnapshot:n,remoteSnapshot:i}=await t.snapshotHandler.loadRemoteSnapshotInfo(r),a=await this.hooks.lifecycle.generatePreloadAssets.emit({origin:t,preloadOptions:e,remote:r,remoteInfo:o,globalSnapshot:n,remoteSnapshot:i});a&&th(o,t,a)}))}registerRemotes(e,t){let{host:r}=this;e.forEach(e=>{this.registerRemote(e,r.options.remotes,{force:null==t?void 0:t.force})})}async getRemoteModuleAndOptions(e){let t,{host:r}=this,{id:n}=e;try{t=await this.hooks.lifecycle.beforeRequest.emit({id:n,options:r.options,origin:r})}catch(e){if(!(t=await this.hooks.lifecycle.errorLoadRemote.emit({id:n,options:r.options,origin:r,from:"runtime",error:e,lifecycle:"beforeRequest"})))throw e}let{id:a}=t,s=e8(r.options.remotes,a);l(s,i.getShortErrorMsg(i.RUNTIME_004,i.runtimeDescMap,{hostName:r.options.name,requestId:a}));let{remote:c}=s,u=to(c),d=await r.sharedHandler.hooks.lifecycle.afterResolve.emit(o._extends({id:a},s,{options:r.options,origin:r,remoteInfo:u})),{remote:p,expose:f}=d;l(p&&f,`The 'beforeRequest' hook was executed, but it failed to return the correct 'remote' and 'expose' values while loading ${a}.`);let h=r.moduleCache.get(p.name),m={host:r,remoteInfo:u};return h||(h=new tn(m),r.moduleCache.set(p.name,h)),{module:h,moduleOptions:m,remoteMatchInfo:d}}registerRemote(e,t,r){let{host:o}=this,i=()=>{if(e.alias){let r=t.find(t=>{var r;return e.alias&&(t.name.startsWith(e.alias)||(null==(r=t.alias)?void 0:r.startsWith(e.alias)))});l(!r,`The alias ${e.alias} of remote ${e.name} is not allowed to be the prefix of ${r&&r.name} name or alias`)}"entry"in e&&n.isBrowserEnv()&&!e.entry.startsWith("http")&&(e.entry=new URL(e.entry,window.location.origin).href),e.shareScope||(e.shareScope=z),e.type||(e.type=q)};this.hooks.lifecycle.beforeRegisterRemote.emit({remote:e,origin:o});let a=t.find(t=>t.name===e.name);if(a){let s=[`The remote "${e.name}" is already registered.`,"Please note that overriding it may cause unexpected errors."];(null==r?void 0:r.force)&&(this.removeRemote(a),i(),t.push(e),this.hooks.lifecycle.registerRemote.emit({remote:e,origin:o}),n.warn(s.join(" ")))}else i(),t.push(e),this.hooks.lifecycle.registerRemote.emit({remote:e,origin:o})}removeRemote(e){try{let{host:r}=this,{name:o}=e,i=r.options.remotes.findIndex(e=>e.name===o);-1!==i&&r.options.remotes.splice(i,1);let a=r.moduleCache.get(e.name);if(a){let o=a.remoteInfo,i=o.entryGlobalName;if(x[i]){var t;(null==(t=Object.getOwnPropertyDescriptor(x,i))?void 0:t.configurable)?delete x[i]:x[i]=void 0}let s=tt(a.remoteInfo);I[s]&&delete I[s],r.snapshotHandler.manifestCache.delete(o.entry);let l=o.buildVersion?n.composeKeyWithSeparator(o.name,o.buildVersion):o.name,c=x.__FEDERATION__.__INSTANCES__.findIndex(e=>o.buildVersion?e.options.id===l:e.name===l);if(-1!==c){let e=x.__FEDERATION__.__INSTANCES__[c];l=e.options.id||l;let t=eQ(),r=!0,n=[];Object.keys(t).forEach(e=>{let i=t[e];i&&Object.keys(i).forEach(t=>{let a=i[t];a&&Object.keys(a).forEach(i=>{let s=a[i];s&&Object.keys(s).forEach(a=>{let l=s[a];l&&"object"==typeof l&&l.from===o.name&&(l.loaded||l.loading?(l.useIn=l.useIn.filter(e=>e!==o.name),l.useIn.length?r=!1:n.push([e,t,i,a])):n.push([e,t,i,a]))})})})}),r&&(e.shareScopeMap={},delete t[l]),n.forEach(e=>{var r,o,n;let[i,a,s,l]=e;null==(n=t[i])||null==(o=n[a])||null==(r=o[s])||delete r[l]}),x.__FEDERATION__.__INSTANCES__.splice(c,1)}let{hostGlobalSnapshot:u}=tS(e,r);if(u){let t=u&&"remotesInfo"in u&&u.remotesInfo&&P(u.remotesInfo,e.name).key;t&&(delete u.remotesInfo[t],w.__FEDERATION__.__MANIFEST_LOADING__[t]&&delete w.__FEDERATION__.__MANIFEST_LOADING__[t])}r.moduleCache.delete(e.name)}}catch(e){s.log("removeRemote fail: ",e)}}constructor(e){this.hooks=new tu({beforeRegisterRemote:new tl("beforeRegisterRemote"),registerRemote:new tl("registerRemote"),beforeRequest:new tc("beforeRequest"),onLoad:new ta("onLoad"),handlePreloadModule:new ti("handlePreloadModule"),errorLoadRemote:new ta("errorLoadRemote"),beforePreloadRemote:new ta("beforePreloadRemote"),generatePreloadAssets:new ta("generatePreloadAssets"),afterPreloadRemote:new ta,loadEntry:new ta}),this.host=e,this.idToRemoteMap={}}}class tT{initOptions(e){this.registerPlugins(e.plugins);let t=this.formatOptions(this.options,e);return this.options=t,t}async loadShare(e,t){return this.sharedHandler.loadShare(e,t)}loadShareSync(e,t){return this.sharedHandler.loadShareSync(e,t)}initializeSharing(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:z,t=arguments.length>1?arguments[1]:void 0;return this.sharedHandler.initializeSharing(e,t)}initRawContainer(e,t,r){let o=new tn({host:this,remoteInfo:to({name:e,entry:t})});return o.remoteEntryExports=r,this.moduleCache.set(e,o),o}async loadRemote(e,t){return this.remoteHandler.loadRemote(e,t)}async preloadRemote(e){return this.remoteHandler.preloadRemote(e)}initShareScopeMap(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:{};this.sharedHandler.initShareScopeMap(e,t,r)}formatOptions(e,t){let{shared:r}=eV(e,t),{userOptions:n,options:i}=this.hooks.lifecycle.beforeInit.emit({origin:this,userOptions:t,options:e,shareInfo:r}),a=this.remoteHandler.formatAndRegisterRemote(i,n),{shared:s}=this.sharedHandler.registerShared(i,n),l=[...i.plugins];n.plugins&&n.plugins.forEach(e=>{l.includes(e)||l.push(e)});let c=o._extends({},e,t,{plugins:l,remotes:a,shared:s});return this.hooks.lifecycle.init.emit({origin:this,options:c}),c}registerPlugins(e){let t=e6(e,[this.hooks,this.remoteHandler.hooks,this.sharedHandler.hooks,this.snapshotHandler.hooks,this.loaderHook,this.bridgeHook]);this.options.plugins=this.options.plugins.reduce((e,t)=>(t&&e&&!e.find(e=>e.name===t.name)&&e.push(t),e),t||[])}registerRemotes(e,t){return this.remoteHandler.registerRemotes(e,t)}constructor(e){this.hooks=new tu({beforeInit:new tl("beforeInit"),init:new ti,beforeInitContainer:new tc("beforeInitContainer"),initContainer:new tc("initContainer")}),this.version="0.13.1",this.moduleCache=new Map,this.loaderHook=new tu({getModuleInfo:new ti,createScript:new ti,createLink:new ti,fetch:new ta,loadEntryError:new ta,getModuleFactory:new ta}),this.bridgeHook=new tu({beforeBridgeRender:new ti,afterBridgeRender:new ti,beforeBridgeDestroy:new ti,afterBridgeDestroy:new ti});const t={id:e2(),name:e.name,plugins:[tg(),tv()],remotes:[],shared:{},inBrowser:n.isBrowserEnv()};this.name=e.name,this.options=t,this.snapshotHandler=new tx(this),this.sharedHandler=new t$(this),this.remoteHandler=new tw(this),this.shareScopeMap=this.sharedHandler.shareScopeMap,this.registerPlugins([...t.plugins,...e.plugins||[]]),this.options=this.formatOptions(t,e)}}var tR=Object.freeze({__proto__:null});t.loadScript=n.loadScript,t.loadScriptNode=n.loadScriptNode,t.CurrentGlobal=x,t.FederationHost=tT,t.Global=w,t.Module=tn,t.addGlobalSnapshot=H,t.assert=l,t.getGlobalFederationConstructor=k,t.getGlobalSnapshot=D,t.getInfoWithoutType=P,t.getRegisteredShare=eZ,t.getRemoteEntry=tr,t.getRemoteInfo=to,t.helpers=e1,t.isStaticResourcesEqual=b,t.matchRemoteWithNameAndExpose=e8,t.registerGlobalPlugins=U,t.resetFederationGlobalInfo=O,t.safeWrapper=m,t.satisfy=eG,t.setGlobalFederationConstructor=M,t.setGlobalFederationInstance=A,t.types=tR},6558(e,t){function r(){return(r=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var o in r)Object.prototype.hasOwnProperty.call(r,o)&&(e[o]=r[o])}return e}).apply(this,arguments)}function o(e,t){if(null==e)return{};var r,o,n={},i=Object.keys(e);for(o=0;o<i.length;o++)r=i[o],t.indexOf(r)>=0||(n[r]=e[r]);return n}t._extends=r,t._object_without_properties_loose=o},5646(e,t,r){var o=r(8306),n=r(4969);let i=null;function a(e){let t=n.getGlobalFederationInstance(e.name,e.version);return t?(t.initOptions(e),i||(i=t),t):(i=new(o.getGlobalFederationConstructor()||o.FederationHost)(e),o.setGlobalFederationInstance(i),i)}function s(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return o.assert(i,"Please call init first"),i.loadRemote.apply(i,t)}function l(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return o.assert(i,"Please call init first"),i.loadShare.apply(i,t)}function c(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return o.assert(i,"Please call init first"),i.loadShareSync.apply(i,t)}function u(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return o.assert(i,"Please call init first"),i.preloadRemote.apply(i,t)}function d(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return o.assert(i,"Please call init first"),i.registerRemotes.apply(i,t)}function p(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return o.assert(i,"Please call init first"),i.registerPlugins.apply(i,t)}function f(){return i}o.setGlobalFederationConstructor(o.FederationHost),t.FederationHost=o.FederationHost,t.Module=o.Module,t.getRemoteEntry=o.getRemoteEntry,t.getRemoteInfo=o.getRemoteInfo,t.loadScript=o.loadScript,t.loadScriptNode=o.loadScriptNode,t.registerGlobalPlugins=o.registerGlobalPlugins,t.getInstance=f,t.init=a,t.loadRemote=s,t.loadShare=l,t.loadShareSync=c,t.preloadRemote=u,t.registerPlugins=p,t.registerRemotes=d},4969(e,t,r){var o=r(8306);function n(){return"datadefinitions:1.0.0"}t.getGlobalFederationInstance=function(e,t){let r=n();return o.CurrentGlobal.__FEDERATION__.__INSTANCES__.find(o=>!!r&&o.options.id===n()||o.options.name===e&&!o.options.version&&!t||o.options.name===e&&!!t&&o.options.version===t)}},318(__unused_rspack_module,exports,__webpack_require__){var polyfills=__webpack_require__(4122);let FederationModuleManifest="federation-manifest.json",MANIFEST_EXT=".json",BROWSER_LOG_KEY="FEDERATION_DEBUG",BROWSER_LOG_VALUE="1",NameTransformSymbol={AT:"@",HYPHEN:"-",SLASH:"/"},NameTransformMap={[NameTransformSymbol.AT]:"scope_",[NameTransformSymbol.HYPHEN]:"_",[NameTransformSymbol.SLASH]:"__"},EncodedNameTransformMap={[NameTransformMap[NameTransformSymbol.AT]]:NameTransformSymbol.AT,[NameTransformMap[NameTransformSymbol.HYPHEN]]:NameTransformSymbol.HYPHEN,[NameTransformMap[NameTransformSymbol.SLASH]]:NameTransformSymbol.SLASH},SEPARATOR=":",ManifestFileName="mf-manifest.json",StatsFileName="mf-stats.json",MFModuleType={NPM:"npm",APP:"app"},MODULE_DEVTOOL_IDENTIFIER="__MF_DEVTOOLS_MODULE_INFO__",ENCODE_NAME_PREFIX="ENCODE_NAME_PREFIX",TEMP_DIR=".federation",MFPrefetchCommon={identifier:"MFDataPrefetch",globalKey:"__PREFETCH__",library:"mf-data-prefetch",exportsKey:"__PREFETCH_EXPORTS__",fileName:"bootstrap.js"};var ContainerPlugin=Object.freeze({__proto__:null}),ContainerReferencePlugin=Object.freeze({__proto__:null}),ModuleFederationPlugin=Object.freeze({__proto__:null}),SharePlugin=Object.freeze({__proto__:null});function isBrowserEnv(){return"u">typeof window&&void 0!==window.document}function isReactNativeEnv(){var e;return"u">typeof navigator&&(null==(e=navigator)?void 0:e.product)==="ReactNative"}function isBrowserDebug(){try{if(isBrowserEnv()&&window.localStorage)return localStorage.getItem(BROWSER_LOG_KEY)===BROWSER_LOG_VALUE}catch(e){}return!1}function isDebugMode(){return"u">typeof process&&process.env&&process.env.FEDERATION_DEBUG?!!process.env.FEDERATION_DEBUG:!!("u">typeof FEDERATION_DEBUG&&FEDERATION_DEBUG)||isBrowserDebug()}let getProcessEnv=function(){return"u">typeof process&&process.env?process.env:{}},LOG_CATEGORY="[ Federation Runtime ]",parseEntry=function(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:SEPARATOR,o=e.split(r),n="development"===getProcessEnv().NODE_ENV&&t,i="*",a=e=>e.startsWith("http")||e.includes(MANIFEST_EXT);if(o.length>=2){let[t,...s]=o;e.startsWith(r)&&(t=o.slice(0,2).join(r),s=[n||o.slice(2).join(r)]);let l=n||s.join(r);return a(l)?{name:t,entry:l}:{name:t,version:l||i}}if(1===o.length){let[e]=o;return n&&a(n)?{name:e,entry:n}:{name:e,version:n||i}}throw`Invalid entry value: ${e}`},composeKeyWithSeparator=function(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];return t.length?t.reduce((e,t)=>t?e?`${e}${SEPARATOR}${t}`:t:e,""):""},encodeName=function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"",r=arguments.length>2&&void 0!==arguments[2]&&arguments[2];try{let o=r?".js":"";return`${t}${e.replace(RegExp(`${NameTransformSymbol.AT}`,"g"),NameTransformMap[NameTransformSymbol.AT]).replace(RegExp(`${NameTransformSymbol.HYPHEN}`,"g"),NameTransformMap[NameTransformSymbol.HYPHEN]).replace(RegExp(`${NameTransformSymbol.SLASH}`,"g"),NameTransformMap[NameTransformSymbol.SLASH])}${o}`}catch(e){throw e}},decodeName=function(e,t,r){try{let o=e;if(t){if(!o.startsWith(t))return o;o=o.replace(RegExp(t,"g"),"")}return o=o.replace(RegExp(`${NameTransformMap[NameTransformSymbol.AT]}`,"g"),EncodedNameTransformMap[NameTransformMap[NameTransformSymbol.AT]]).replace(RegExp(`${NameTransformMap[NameTransformSymbol.SLASH]}`,"g"),EncodedNameTransformMap[NameTransformMap[NameTransformSymbol.SLASH]]).replace(RegExp(`${NameTransformMap[NameTransformSymbol.HYPHEN]}`,"g"),EncodedNameTransformMap[NameTransformMap[NameTransformSymbol.HYPHEN]]),r&&(o=o.replace(".js","")),o}catch(e){throw e}},generateExposeFilename=(e,t)=>{if(!e)return"";let r=e;return"."===r&&(r="default_export"),r.startsWith("./")&&(r=r.replace("./","")),encodeName(r,"__federation_expose_",t)},generateShareFilename=(e,t)=>e?encodeName(e,"__federation_shared_",t):"",getResourceUrl=(e,t)=>{if("getPublicPath"in e){let r;return r=e.getPublicPath.startsWith("function")?Function("return "+e.getPublicPath)()():Function(e.getPublicPath)(),`${r}${t}`}return"publicPath"in e?!isBrowserEnv()&&!isReactNativeEnv()&&"ssrPublicPath"in e?`${e.ssrPublicPath}${t}`:`${e.publicPath}${t}`:(console.warn("Cannot get resource URL. If in debug mode, please ignore.",e,t),"")},assert=(e,t)=>{e||error(t)},error=e=>{throw Error(`${LOG_CATEGORY}: ${e}`)},warn=e=>{console.warn(`${LOG_CATEGORY}: ${e}`)};function safeToString(e){try{return JSON.stringify(e,null,2)}catch(e){return""}}let VERSION_PATTERN_REGEXP=/^([\d^=v<>~]|[*xX]$)/;function isRequiredVersion(e){return VERSION_PATTERN_REGEXP.test(e)}let simpleJoinRemoteEntry=(e,t)=>{if(!e)return t;let r=(e=>{if("."===e)return"";if(e.startsWith("./"))return e.replace("./","");if(e.startsWith("/")){let t=e.slice(1);return t.endsWith("/")?t.slice(0,-1):t}return e})(e);return r?r.endsWith("/")?`${r}${t}`:`${r}/${t}`:t};function inferAutoPublicPath(e){return e.replace(/#.*$/,"").replace(/\?.*$/,"").replace(/\/[^\/]+$/,"/")}function generateSnapshotFromManifest(e){var t,r,o;let n,i=arguments.length>1&&void 0!==arguments[1]?arguments[1]:{},{remotes:a={},overrides:s={},version:l}=i,c=()=>"publicPath"in e.metaData?"auto"===e.metaData.publicPath&&l?inferAutoPublicPath(l):e.metaData.publicPath:e.metaData.getPublicPath,u=Object.keys(s),d={};Object.keys(a).length||(d=(null==(o=e.remotes)?void 0:o.reduce((e,t)=>{let r,o=t.federationContainerName;return r=u.includes(o)?s[o]:"version"in t?t.version:t.entry,e[o]={matchedVersion:r},e},{}))||{}),Object.keys(a).forEach(e=>d[e]={matchedVersion:u.includes(e)?s[e]:a[e]});let{remoteEntry:{path:p,name:f,type:h},types:m,buildInfo:{buildVersion:g},globalName:y,ssrRemoteEntry:_}=e.metaData,{exposes:b}=e,E={version:l||"",buildVersion:g,globalName:y,remoteEntry:simpleJoinRemoteEntry(p,f),remoteEntryType:h,remoteTypes:simpleJoinRemoteEntry(m.path,m.name),remoteTypesZip:m.zip||"",remoteTypesAPI:m.api||"",remotesInfo:d,shared:null==e?void 0:e.shared.map(e=>({assets:e.assets,sharedName:e.name,version:e.version})),modules:null==b?void 0:b.map(e=>({moduleName:e.name,modulePath:e.path,assets:e.assets}))};if(null==(t=e.metaData)?void 0:t.prefetchInterface){let t=e.metaData.prefetchInterface;E=polyfills._({},E,{prefetchInterface:t})}if(null==(r=e.metaData)?void 0:r.prefetchEntry){let{path:t,name:r,type:o}=e.metaData.prefetchEntry;E=polyfills._({},E,{prefetchEntry:simpleJoinRemoteEntry(t,r),prefetchEntryType:o})}return n="publicPath"in e.metaData?polyfills._({},E,{publicPath:c(),ssrPublicPath:e.metaData.ssrPublicPath}):polyfills._({},E,{getPublicPath:c()}),_&&(n.ssrRemoteEntry=simpleJoinRemoteEntry(_.path,_.name),n.ssrRemoteEntryType=_.type||"commonjs-module"),n}function isManifestProvider(e){return!!("remoteEntry"in e&&e.remoteEntry.includes(MANIFEST_EXT))}let PREFIX="[ Module Federation ]",Logger=class{setPrefix(e){this.prefix=e}log(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];console.log(this.prefix,...t)}warn(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];console.log(this.prefix,...t)}error(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];console.log(this.prefix,...t)}success(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];console.log(this.prefix,...t)}info(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];console.log(this.prefix,...t)}ready(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];console.log(this.prefix,...t)}debug(){for(var e=arguments.length,t=Array(e),r=0;r<e;r++)t[r]=arguments[r];isDebugMode()&&console.log(this.prefix,...t)}constructor(e){this.prefix=e}};function createLogger(e){return new Logger(e)}let logger=createLogger(PREFIX);async function safeWrapper(e,t){try{return await e()}catch(e){t||warn(e);return}}function isStaticResourcesEqual(e,t){let r=/^(https?:)?\/\//i;return e.replace(r,"").replace(/\/$/,"")===t.replace(r,"").replace(/\/$/,"")}function createScript(e){let t,r=null,o=!0,n=2e4,i=document.getElementsByTagName("script");for(let t=0;t<i.length;t++){let n=i[t],a=n.getAttribute("src");if(a&&isStaticResourcesEqual(a,e.url)){r=n,o=!1;break}}if(!r){let t,o=e.attrs;(r=document.createElement("script")).type=(null==o?void 0:o.type)==="module"?"module":"text/javascript",e.createScriptHook&&((t=e.createScriptHook(e.url,e.attrs))instanceof HTMLScriptElement?r=t:"object"==typeof t&&("script"in t&&t.script&&(r=t.script),"timeout"in t&&t.timeout&&(n=t.timeout))),r.src||(r.src=e.url),o&&!t&&Object.keys(o).forEach(e=>{r&&("async"===e||"defer"===e?r[e]=o[e]:r.getAttribute(e)||r.setAttribute(e,o[e]))})}let a=async(o,n)=>{clearTimeout(t);let i=()=>{(null==n?void 0:n.type)==="error"?(null==e?void 0:e.onErrorCallback)&&(null==e||e.onErrorCallback(n)):(null==e?void 0:e.cb)&&(null==e||e.cb())};if(r&&(r.onerror=null,r.onload=null,safeWrapper(()=>{let{needDeleteScript:t=!0}=e;t&&(null==r?void 0:r.parentNode)&&r.parentNode.removeChild(r)}),o&&"function"==typeof o)){let e=o(n);if(e instanceof Promise){let t=await e;return i(),t}return i(),e}i()};return r.onerror=a.bind(null,r.onerror),r.onload=a.bind(null,r.onload),t=setTimeout(()=>{a(null,Error(`Remote script "${e.url}" time-outed.`))},n),{script:r,needAttach:o}}function createLink(e){let t=null,r=!0,o=document.getElementsByTagName("link");for(let n=0;n<o.length;n++){let i=o[n],a=i.getAttribute("href"),s=i.getAttribute("rel");if(a&&isStaticResourcesEqual(a,e.url)&&s===e.attrs.rel){t=i,r=!1;break}}if(!t){let r;(t=document.createElement("link")).setAttribute("href",e.url);let o=e.attrs;e.createLinkHook&&(r=e.createLinkHook(e.url,o))instanceof HTMLLinkElement&&(t=r),o&&!r&&Object.keys(o).forEach(e=>{t&&!t.getAttribute(e)&&t.setAttribute(e,o[e])})}let n=(r,o)=>{let n=()=>{(null==o?void 0:o.type)==="error"?(null==e?void 0:e.onErrorCallback)&&(null==e||e.onErrorCallback(o)):(null==e?void 0:e.cb)&&(null==e||e.cb())};if(t&&(t.onerror=null,t.onload=null,safeWrapper(()=>{let{needDeleteLink:r=!0}=e;r&&(null==t?void 0:t.parentNode)&&t.parentNode.removeChild(t)}),r)){let e=r(o);return n(),e}n()};return t.onerror=n.bind(null,t.onerror),t.onload=n.bind(null,t.onload),{link:t,needAttach:r}}function loadScript(e,t){let{attrs:r={},createScriptHook:o}=t;return new Promise((t,n)=>{let{script:i,needAttach:a}=createScript({url:e,cb:t,onErrorCallback:n,attrs:polyfills._({fetchpriority:"high"},r),createScriptHook:o,needDeleteScript:!0});a&&document.head.appendChild(i)})}function importNodeModule(e){if(!e)throw Error("import specifier is required");return Function("name","return import(name)")(e).then(e=>e).catch(t=>{throw console.error(`Error importing module ${e}:`,t),t})}let loadNodeFetch=async()=>{let e=await importNodeModule("node-fetch");return e.default||e},lazyLoaderHookFetch=async(e,t,r)=>{let o=(e,t)=>r.lifecycle.fetch.emit(e,t),n=await o(e,t||{});return n&&n instanceof Response?n:("u"<typeof fetch?await loadNodeFetch():fetch)(e,t||{})};function createScriptNode(url,cb,attrs,loaderHook){let urlObj;if(null==loaderHook?void 0:loaderHook.createScriptHook){let hookResult=loaderHook.createScriptHook(url);hookResult&&"object"==typeof hookResult&&"url"in hookResult&&(url=hookResult.url)}try{urlObj=new URL(url)}catch(e){console.error("Error constructing URL:",e),cb(Error(`Invalid URL: ${e}`));return}let getFetch=async()=>(null==loaderHook?void 0:loaderHook.fetch)?(e,t)=>lazyLoaderHookFetch(e,t,loaderHook):"u"<typeof fetch?loadNodeFetch():fetch,handleScriptFetch=async(f,urlObj)=>{try{var _vm_constants,_vm_constants_USE_MAIN_CONTEXT_DEFAULT_LOADER;let res=await f(urlObj.href),data=await res.text(),[path,vm]=await Promise.all([importNodeModule("path"),importNodeModule("vm")]),scriptContext={exports:{},module:{exports:{}}},urlDirname=urlObj.pathname.split("/").slice(0,-1).join("/"),filename=path.basename(urlObj.pathname),script=new vm.Script(`(function(exports, module, require, __dirname, __filename) {${data}
})`,{filename,importModuleDynamically:null!=(_vm_constants_USE_MAIN_CONTEXT_DEFAULT_LOADER=null==(_vm_constants=vm.constants)?void 0:_vm_constants.USE_MAIN_CONTEXT_DEFAULT_LOADER)?_vm_constants_USE_MAIN_CONTEXT_DEFAULT_LOADER:importNodeModule});script.runInThisContext()(scriptContext.exports,scriptContext.module,eval("require"),urlDirname,filename);let exportedInterface=scriptContext.module.exports||scriptContext.exports;if(attrs&&exportedInterface&&attrs.globalName){let container=exportedInterface[attrs.globalName]||exportedInterface;cb(void 0,container);return}cb(void 0,exportedInterface)}catch(e){cb(e instanceof Error?e:Error(`Script execution error: ${e}`))}};getFetch().then(async e=>{if((null==attrs?void 0:attrs.type)==="esm"||(null==attrs?void 0:attrs.type)==="module")return loadModule(urlObj.href,{fetch:e,vm:await importNodeModule("vm")}).then(async e=>{await e.evaluate(),cb(void 0,e.namespace)}).catch(e=>{cb(e instanceof Error?e:Error(`Script execution error: ${e}`))});handleScriptFetch(e,urlObj)}).catch(e=>{cb(e)})}function loadScriptNode(e,t){return new Promise((r,o)=>{createScriptNode(e,(e,n)=>{if(e)o(e);else{var i,a;let e=(null==t||null==(i=t.attrs)?void 0:i.globalName)||`__FEDERATION_${null==t||null==(a=t.attrs)?void 0:a.name}:custom__`;r(globalThis[e]=n)}},t.attrs,t.loaderHook)})}async function loadModule(e,t){let{fetch:r,vm:o}=t,n=await r(e),i=await n.text(),a=new o.SourceTextModule(i,{importModuleDynamically:async(r,o)=>loadModule(new URL(r,e).href,t)});return await a.link(async r=>{let o=new URL(r,e).href;return await loadModule(o,t)}),a}function normalizeOptions(e,t,r){return function(o){if(!1===o)return!1;if(void 0===o)if(e)return t;else return!1;if(!0===o)return t;if(o&&"object"==typeof o)return polyfills._({},t,o);throw Error(`Unexpected type for \`${r}\`, expect boolean/undefined/object, got: ${typeof o}`)}}exports.BROWSER_LOG_KEY=BROWSER_LOG_KEY,exports.BROWSER_LOG_VALUE=BROWSER_LOG_VALUE,exports.ENCODE_NAME_PREFIX=ENCODE_NAME_PREFIX,exports.EncodedNameTransformMap=EncodedNameTransformMap,exports.FederationModuleManifest=FederationModuleManifest,exports.MANIFEST_EXT=MANIFEST_EXT,exports.MFModuleType=MFModuleType,exports.MFPrefetchCommon=MFPrefetchCommon,exports.MODULE_DEVTOOL_IDENTIFIER=MODULE_DEVTOOL_IDENTIFIER,exports.ManifestFileName=ManifestFileName,exports.NameTransformMap=NameTransformMap,exports.NameTransformSymbol=NameTransformSymbol,exports.SEPARATOR=SEPARATOR,exports.StatsFileName=StatsFileName,exports.TEMP_DIR=TEMP_DIR,exports.assert=assert,exports.composeKeyWithSeparator=composeKeyWithSeparator,exports.containerPlugin=ContainerPlugin,exports.containerReferencePlugin=ContainerReferencePlugin,exports.createLink=createLink,exports.createLogger=createLogger,exports.createScript=createScript,exports.createScriptNode=createScriptNode,exports.decodeName=decodeName,exports.encodeName=encodeName,exports.error=error,exports.generateExposeFilename=generateExposeFilename,exports.generateShareFilename=generateShareFilename,exports.generateSnapshotFromManifest=generateSnapshotFromManifest,exports.getProcessEnv=getProcessEnv,exports.getResourceUrl=getResourceUrl,exports.inferAutoPublicPath=inferAutoPublicPath,exports.isBrowserEnv=isBrowserEnv,exports.isDebugMode=isDebugMode,exports.isManifestProvider=isManifestProvider,exports.isReactNativeEnv=isReactNativeEnv,exports.isRequiredVersion=isRequiredVersion,exports.isStaticResourcesEqual=isStaticResourcesEqual,exports.loadScript=loadScript,exports.loadScriptNode=loadScriptNode,exports.logger=logger,exports.moduleFederationPlugin=ModuleFederationPlugin,exports.normalizeOptions=normalizeOptions,exports.parseEntry=parseEntry,exports.safeToString=safeToString,exports.safeWrapper=safeWrapper,exports.sharePlugin=SharePlugin,exports.simpleJoinRemoteEntry=simpleJoinRemoteEntry,exports.warn=warn},4122(e,t){function r(){return(r=Object.assign||function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var o in r)Object.prototype.hasOwnProperty.call(r,o)&&(e[o]=r[o])}return e}).apply(this,arguments)}t._=r},9570(e,t,r){r(2977),r(4781),r(8615),r(5906);var o=r(3987);r(4484);var n=r(2818);(0,n.rU)(e=>{let{css:t,token:r}=e;return{container:t`
    display: flex;
    height: 100%;
    background: ${r.colorBgContainer};
  `,sidebar:t`
    width: 280px;
    border-right: 1px solid ${r.colorBorderSecondary};
    display: flex;
    flex-direction: column;
  `,sidebarHeader:t`
    padding: 16px;
    border-bottom: 1px solid ${r.colorBorderSecondary};
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-weight: 600;
  `,sidebarList:t`
    flex: 1;
    overflow-y: auto;
    .ant-list-item {
      cursor: pointer;
      padding: 12px 16px;
      &:hover {
        background: ${r.colorBgTextHover};
      }
    }
  `,content:t`
    flex: 1;
    display: flex;
    flex-direction: column;
    overflow: hidden;
  `,tabsContainer:t`
    flex: 1;
    overflow: hidden;
    .ant-tabs {
      height: 100%;
    }
    .ant-tabs-content {
      height: 100%;
    }
    .ant-tabs-tabpane {
      height: 100%;
      overflow: auto;
    }
  `,tabContent:t`
    height: 100%;
    display: flex;
    flex-direction: column;
  `,tabBody:t`
    flex: 1;
    min-height: 0;
    overflow: auto;
  `,footer:t`
    padding: 8px 16px;
    border-top: 1px solid ${r.colorBorderSecondary};
    background: ${r.colorBgContainer};
    display: flex;
    gap: 8px;
    justify-content: flex-end;
  `,emptyContent:t`
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100%;
    color: ${r.colorTextSecondary};
  `}});let i="/admin/data_definitions",a=null;async function s(){if(null!==a)return a;let e=await fetch("/admin/login/csrf-token",{credentials:"include"});return a=(await e.json()).csrfToken??""}async function l(e,t){let r="";try{r=(await t.text()).slice(0,300)}catch{}throw Error(`${e} failed (HTTP ${t.status})${""!==r?`: ${r}`:""}`)}function c(e){if(null!==e&&"object"==typeof e&&!1===e.success)throw Error("string"==typeof e.message&&""!==e.message?e.message:"Request rejected by the server");return(null==e?void 0:e.data)??e}async function u(e){return await fetch(e,{method:"GET",headers:{"Content-Type":"application/json"},credentials:"include"})}async function d(e,t,r){let o=await s();return await fetch(e,{method:t,credentials:"include",headers:{...void 0!==r?{"Content-Type":"application/json"}:{},"x-pimcore-csrf-token":o},...void 0!==r?{body:JSON.stringify(r)}:{}})}class p{async list(){let e=await u(this.buildUrl("/list"));return e.ok||await l("Loading definition list",e),c(await e.json())}async get(e){let t=await u(this.buildUrl(`/get?id=${e}`));return t.ok||await l("Loading definition",t),c(await t.json())}async add(e){let t=await d(this.buildUrl("/add"),"POST",e);return t.ok||await l("Creating definition",t),c(await t.json())}async save(e){let t=await d(this.buildUrl("/save"),"POST",e);return t.ok||await l("Saving definition",t),c(await t.json())}async delete(e){let t=await d(this.buildUrl(`/delete?id=${e}`),"DELETE");t.ok||await l("Deleting definition",t)}async getConfig(){let e=await u(this.buildUrl("/get-config"));return e.ok||await l("Loading configuration",e),await e.json()}async getColumns(e){let t=await u(this.buildUrl(`/get-columns?id=${e}`));return t.ok||await l("Loading columns",t),await t.json()}async export(e){let t=await u(this.buildUrl(`/export?id=${e}`));return t.ok||await l("Exporting definition",t),await t.blob()}async duplicate(e,t){let r=await d(this.buildUrl("/duplicate"),"POST",{id:e,name:t});return r.ok||await l("Duplicating definition",r),c(await r.json())}}class f extends p{buildUrl(e){return`${i}/import_definitions${e}`}async import(e,t){let r=new FormData;r.append("Filedata",t),r.append("id",String(e));let o=await s(),n=await fetch(this.buildUrl("/import"),{method:"POST",credentials:"include",headers:{"x-pimcore-csrf-token":o},body:r});return n.ok||await l("Importing definition",n),c(await n.json())}}class h extends p{buildUrl(e){return`${i}/export_definitions${e}`}}new f,new h;let m=null,g=null,{TextArea:y}=o.Input,{TextArea:_}=o.Input,{Text:b}=o.Typography,{Text:E}=o.Typography,{Text:v}=o.Typography,{Text:S}=o.Typography,{Text:x}=o.Typography,{Text:$}=o.Typography;(0,n.rU)(e=>{let{css:t,token:r}=e;return{tabContent:t`
    padding: 16px 0;
  `,configSection:t`
    background: ${r.colorFillQuaternary};
    border-radius: ${r.borderRadiusLG}px;
    padding: 16px;
    margin-top: 16px;
  `,configSectionTitle:t`
    font-size: 12px;
    font-weight: 600;
    color: ${r.colorTextSecondary};
    letter-spacing: 0.5px;
    margin-bottom: 16px;
  `}}),(0,n.rU)(e=>{let{token:t,css:r}=e;return{container:r`
    height: 100%;
    overflow: auto;
    background: ${t.colorBgContainer};
  `,loadingContainer:r`
    display: flex;
    justify-content: center;
    align-items: center;
    height: 200px;
  `,mappingTable:r`
    .ant-table-thead > tr > th {
      background: ${t.colorFillAlter};
      font-weight: 600;
      padding: 8px 12px;
      border-bottom: 1px solid ${t.colorBorderSecondary};
    }

    .ant-table-tbody > tr > td {
      padding: 4px 12px;
      vertical-align: middle;
    }

    .ant-table-tbody > tr:hover > td {
      background: ${t.colorFillTertiary};
    }
  `,groupHeaderRow:r`
    background: ${t.colorFillSecondary} !important;

    td {
      background: ${t.colorFillSecondary} !important;
      font-weight: 500;
    }

    &:hover td {
      background: ${t.colorFillTertiary} !important;
    }
  `,mappingRow:r`
    &:hover {
      background: ${t.colorFillTertiary};
    }
  `,groupRow:r`
    display: flex;
    align-items: center;
    user-select: none;
    padding: 4px 0;
  `,groupName:r`
    font-weight: 500;
    margin-right: 8px;
  `,groupCount:r`
    color: ${t.colorTextSecondary};
    font-size: 12px;
  `,fieldRow:r`
    display: flex;
    align-items: center;
  `,actionButtons:r`
    display: flex;
    gap: 4px;
    justify-content: flex-end;
  `,panel:r`
    height: 100%;
    display: flex;
    flex-direction: column;
    background: ${t.colorBgContainer};
  `,panelHeader:r`
    padding: 8px 12px;
    border-bottom: 1px solid ${t.colorBorderSecondary};
    background: ${t.colorFillAlter};
  `,panelTitle:r`
    margin: 0 !important;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  `,panelBody:r`
    flex: 1;
    overflow: auto;
    padding: 8px;
  `,loading:r`
    padding: 20px;
    text-align: center;
    color: ${t.colorTextSecondary};
  `,groupTitle:r`
    font-weight: 500;
    color: ${t.colorText};
  `,fieldItem:r`
    display: flex;
    align-items: center;
    gap: 8px;
  `,fieldName:r`
    color: ${t.colorText};
  `,fieldType:r`
    color: ${t.colorTextSecondary};
    font-size: 11px;
    text-transform: uppercase;
  `,mappingItem:r`
    display: flex;
    align-items: center;
    gap: 8px;
  `,mappingName:r`
    color: ${t.colorText};
    font-weight: 500;
  `,mappingFrom:r`
    color: ${t.colorTextSecondary};
    font-size: 12px;
  `,mappingType:r`
    color: ${t.colorTextTertiary};
    font-size: 11px;
  `,mappingActions:r`
    display: flex;
    gap: 4px;
    margin-left: auto;
  `}});(0,n.rU)(e=>{let{token:t,css:r}=e;return{container:r`
    padding: 16px;
  `,section:r`
    background: ${t.colorBgContainer};
    border: 1px solid ${t.colorBorderSecondary};
    border-radius: ${t.borderRadiusLG}px;
    padding: 16px;
    margin-bottom: 16px;

    &:last-child {
      margin-bottom: 0;
    }
  `,sectionTitle:r`
    font-size: 13px;
    font-weight: 600;
    color: ${t.colorTextSecondary};
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 16px;
    padding-bottom: 8px;
    border-bottom: 1px solid ${t.colorBorderSecondary};
    display: flex;
    align-items: center;
    gap: 8px;
  `,sectionIcon:r`
    font-size: 16px;
    color: ${t.colorPrimary};
  `,row:r`
    display: flex;
    gap: 16px;
    margin-bottom: 16px;

    &:last-child {
      margin-bottom: 0;
    }
  `,field:r`
    flex: 1;
  `,fieldSmall:r`
    width: 120px;
    flex-shrink: 0;
  `,fieldLabel:r`
    font-size: 12px;
    font-weight: 500;
    color: ${t.colorText};
    margin-bottom: 6px;
    display: block;
  `,fieldHelp:r`
    font-size: 11px;
    color: ${t.colorTextTertiary};
    margin-top: 4px;
  `,codeEditor:r`
    font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
    font-size: 12px;
    background: ${t.colorFillTertiary};
    border-radius: ${t.borderRadius}px;

    &.ant-input {
      background: ${t.colorFillTertiary};
    }
  `,previewSection:r`
    background: ${t.colorFillAlter};
    border: 1px dashed ${t.colorBorder};
    border-radius: ${t.borderRadius}px;
    padding: 12px;
    margin-top: 8px;
  `,previewLabel:r`
    font-size: 11px;
    font-weight: 500;
    color: ${t.colorTextSecondary};
    margin-bottom: 8px;
    text-transform: uppercase;
  `,previewContent:r`
    font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
    font-size: 11px;
    color: ${t.colorText};
    white-space: pre-wrap;
    word-break: break-all;
  `,inlineGroup:r`
    display: flex;
    gap: 12px;
    align-items: flex-start;
  `,checkbox:r`
    margin-top: 4px;
  `,divider:r`
    height: 1px;
    background: ${t.colorBorderSecondary};
    margin: 16px 0;
  `,alert:r`
    margin-bottom: 16px;
  `,storageSelect:r`
    min-width: 200px;
  `}});let{TextArea:w}=o.Input,{TextArea:T}=o.Input,{TextArea:R}=o.Input,{TextArea:I}=o.Input,{TextArea:N}=o.Input,{TextArea:O}=o.Input,{TextArea:A}=o.Input;(0,n.rU)(e=>{let{css:t,token:r}=e;return{root:t`
    display: flex;
    flex-direction: column;
    height: 100%;
    overflow: hidden;

    .ant-tabs {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .ant-tabs-content-holder {
      flex: 1;
      overflow: hidden;
    }

    .ant-tabs-content {
      height: 100%;
    }

    .ant-tabs-tabpane {
      height: 100%;
      overflow: auto;
    }
  `,header:t`
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 24px;
    border-bottom: 1px solid ${r.colorBorderSecondary};
    background: ${r.colorBgContainer};
    flex-shrink: 0;
  `,title:t`
    font-size: 16px;
    font-weight: 600;
    color: ${r.colorText};
  `,tabContent:t`
    padding: 24px;
    height: 100%;
    overflow: auto;
  `,emptyState:t`
    color: ${r.colorTextSecondary};
    text-align: center;
    padding: 48px;
  `}});let k=null,M=null;(0,n.rU)(e=>{let{token:t,css:r}=e;return{container:r`
    height: 100%;
    overflow: auto;
    background: ${t.colorBgContainer};
  `,loadingContainer:r`
    display: flex;
    justify-content: center;
    align-items: center;
    height: 200px;
  `,mappingTable:r`
    .ant-table-thead > tr > th {
      background: ${t.colorFillAlter};
      font-weight: 600;
      padding: 8px 12px;
      border-bottom: 1px solid ${t.colorBorderSecondary};
    }

    .ant-table-tbody > tr > td {
      padding: 4px 12px;
      vertical-align: middle;
    }

    .ant-table-tbody > tr:hover > td {
      background: ${t.colorFillTertiary};
    }
  `,groupHeaderRow:r`
    background: ${t.colorFillSecondary} !important;

    td {
      background: ${t.colorFillSecondary} !important;
      font-weight: 500;
    }

    &:hover td {
      background: ${t.colorFillTertiary} !important;
    }
  `,mappingRow:r`
    &:hover {
      background: ${t.colorFillTertiary};
    }
  `,groupRow:r`
    display: flex;
    align-items: center;
    user-select: none;
    padding: 4px 0;
  `,groupName:r`
    font-weight: 500;
    margin-right: 8px;
  `,groupCount:r`
    color: ${t.colorTextSecondary};
    font-size: 12px;
  `,fieldRow:r`
    display: flex;
    align-items: center;
  `,actionButtons:r`
    display: flex;
    gap: 4px;
    justify-content: flex-end;
  `,panel:r`
    height: 100%;
    display: flex;
    flex-direction: column;
    background: ${t.colorBgContainer};
  `,panelHeader:r`
    padding: 8px 12px;
    border-bottom: 1px solid ${t.colorBorderSecondary};
    background: ${t.colorFillAlter};
  `,panelTitle:r`
    margin: 0 !important;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  `,panelBody:r`
    flex: 1;
    overflow: auto;
    padding: 8px;
  `,loading:r`
    padding: 20px;
    text-align: center;
    color: ${t.colorTextSecondary};
  `,groupTitle:r`
    font-weight: 500;
    color: ${t.colorText};
  `,fieldItem:r`
    display: flex;
    align-items: center;
    gap: 8px;
  `,fieldName:r`
    color: ${t.colorText};
  `,fieldType:r`
    color: ${t.colorTextSecondary};
    font-size: 11px;
    text-transform: uppercase;
  `,mappingItem:r`
    display: flex;
    align-items: center;
    gap: 8px;
  `,mappingName:r`
    color: ${t.colorText};
    font-weight: 500;
  `,mappingTo:r`
    color: ${t.colorTextSecondary};
    font-size: 12px;
  `,mappingType:r`
    color: ${t.colorTextTertiary};
    font-size: 11px;
  `,mappingActions:r`
    display: flex;
    gap: 4px;
    margin-left: auto;
  `}});(0,n.rU)(e=>{let{css:t,token:r}=e;return{root:t`
    display: flex;
    flex-direction: column;
    height: 100%;
    overflow: hidden;

    .ant-tabs {
      flex: 1;
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .ant-tabs-content-holder {
      flex: 1;
      overflow: hidden;
    }

    .ant-tabs-content {
      height: 100%;
    }

    .ant-tabs-tabpane {
      height: 100%;
      overflow: auto;
    }
  `,header:t`
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 12px 24px;
    border-bottom: 1px solid ${r.colorBorderSecondary};
    background: ${r.colorBgContainer};
    flex-shrink: 0;
  `,title:t`
    font-size: 16px;
    font-weight: 600;
    color: ${r.colorText};
  `,tabContent:t`
    padding: 24px;
    height: 100%;
    overflow: auto;
  `,emptyState:t`
    color: ${r.colorTextSecondary};
    text-align: center;
    padding: 48px;
  `}});let{Text:P}=o.Typography},5862(e,t,r){var o,n,i,a,s,l,c,u,d,p,f,h,m=r(264),g=r.n(m);let y=[].filter(e=>{let{plugin:t}=e;return t}).map(e=>{let{plugin:t,params:r}=e;return t(r)}),_={"@pimcore/studio-ui-bundle":[{alias:"@pimcore/studio-ui-bundle",externalType:"promise",shareScope:"default"}]},b="datadefinitions",E="version-first";if((r.initializeSharingData||r.initializeExposesData)&&r.federation){let e=(e,t,r)=>{e&&e[t]&&(e[t]=r)},t=(e,t,r)=>{var o,n,i,a,s,l;let c=r();Array.isArray(c)?(null!=(i=(o=e)[n=t])||(o[n]=[]),e[t].push(...c)):"object"==typeof c&&null!==c&&(null!=(l=(a=e)[s=t])||(a[s]={}),Object.assign(e[t],c))},m=(e,t,r)=>{var o,n,i;null!=(i=(o=e)[n=t])||(o[n]=r())},v=null!=(o=null==(l=r.remotesLoadingData)?void 0:l.chunkMapping)?o:{},S=null!=(n=null==(c=r.remotesLoadingData)?void 0:c.moduleIdToRemoteDataMapping)?n:{},x=null!=(i=null==(u=r.initializeSharingData)?void 0:u.scopeToSharingDataMapping)?i:{},$=null!=(a=null==(d=r.consumesLoadingData)?void 0:d.chunkMapping)?a:{},w=null!=(s=null==(p=r.consumesLoadingData)?void 0:p.moduleIdToConsumeDataMapping)?s:{},T={},R=[],I={},N=null==(f=r.initializeExposesData)?void 0:f.shareScope;for(let e in g())r.federation[e]=g()[e];m(r.federation,"consumesLoadingModuleToHandlerMapping",()=>{let e={};for(let[t,r]of Object.entries(w))e[t]={getter:r.fallback,shareInfo:{shareConfig:{fixedDependencies:!1,requiredVersion:r.requiredVersion,strictVersion:r.strictVersion,singleton:r.singleton,eager:r.eager},scope:[r.shareScope]},shareKey:r.shareKey};return e}),m(r.federation,"initOptions",()=>({})),m(r.federation.initOptions,"name",()=>b),m(r.federation.initOptions,"shareStrategy",()=>E),m(r.federation.initOptions,"shared",()=>{let e={};for(let[t,r]of Object.entries(x))for(let o of r)if("object"==typeof o&&null!==o){let{name:r,version:n,factory:i,eager:a,singleton:s,requiredVersion:l,strictVersion:c}=o,u={},d=function(e){return void 0!==e};d(s)&&(u.singleton=s),d(l)&&(u.requiredVersion=l),d(a)&&(u.eager=a),d(c)&&(u.strictVersion=c);let p={version:n,scope:[t],shareConfig:u,get:i};e[r]?e[r].push(p):e[r]=[p]}return e}),t(r.federation.initOptions,"remotes",()=>Object.values(_).flat().filter(e=>"script"===e.externalType)),t(r.federation.initOptions,"plugins",()=>y),m(r.federation,"bundlerRuntimeOptions",()=>({})),m(r.federation.bundlerRuntimeOptions,"remotes",()=>({})),m(r.federation.bundlerRuntimeOptions.remotes,"chunkMapping",()=>v),m(r.federation.bundlerRuntimeOptions.remotes,"remoteInfos",()=>_),m(r.federation.bundlerRuntimeOptions.remotes,"idToExternalAndNameMapping",()=>{let e={};for(let[t,r]of Object.entries(S))e[t]=[r.shareScope,r.name,r.externalModuleId,r.remoteName];return e}),m(r.federation.bundlerRuntimeOptions.remotes,"webpackRequire",()=>r),t(r.federation.bundlerRuntimeOptions.remotes,"idToRemoteMap",()=>{let e={};for(let[t,r]of Object.entries(S)){let o=_[r.remoteName];o&&(e[t]=o)}return e}),e(r,"S",r.federation.bundlerRuntime.S),r.federation.attachShareScopeMap&&r.federation.attachShareScopeMap(r),e(r.f,"remotes",(e,t)=>r.federation.bundlerRuntime.remotes({chunkId:e,promises:t,chunkMapping:v,idToExternalAndNameMapping:r.federation.bundlerRuntimeOptions.remotes.idToExternalAndNameMapping,idToRemoteMap:r.federation.bundlerRuntimeOptions.remotes.idToRemoteMap,webpackRequire:r})),e(r.f,"consumes",(e,t)=>r.federation.bundlerRuntime.consumes({chunkId:e,promises:t,chunkMapping:$,moduleToHandlerMapping:r.federation.consumesLoadingModuleToHandlerMapping,installedModules:T,webpackRequire:r})),e(r,"I",(e,t)=>r.federation.bundlerRuntime.I({shareScopeName:e,initScope:t,initPromises:R,initTokens:I,webpackRequire:r})),e(r,"initContainer",(e,t,o)=>r.federation.bundlerRuntime.initContainerEntry({shareScope:e,initScope:t,remoteEntryInitOptions:o,shareScopeKey:N,webpackRequire:r})),e(r,"getContainer",(e,t)=>{var o=r.initializeExposesData.moduleMap;return r.R=t,t=Object.prototype.hasOwnProperty.call(o,e)?o[e]():Promise.resolve().then(()=>{throw Error('Module "'+e+'" does not exist in container.')}),r.R=void 0,t}),r.federation.instance=r.federation.runtime.init(r.federation.initOptions),(null==(h=r.consumesLoadingData)?void 0:h.initialConsumes)&&r.federation.bundlerRuntime.installInitialConsumes({webpackRequire:r,installedModules:T,initialConsumes:r.consumesLoadingData.initialConsumes,moduleToHandlerMapping:r.federation.consumesLoadingModuleToHandlerMapping})}},5698(e){e.exports=new Promise(e=>{let t=window.StudioUIBundleRemoteUrl,r=document.createElement("script"),o=!1;(document.querySelectorAll("script").forEach(e=>{if(e.src.replace(/https?:\/\/[^/]+/,"")===t.replace(/https?:\/\/[^/]+/,"")){o=!0;return}}),o)?e({get:e=>window.pimcore_studio_ui_bundle.get(e),init:(...e)=>{try{return window.pimcore_studio_ui_bundle.init(...e)}catch(e){console.log("remote container already initialized")}}}):(r.src=t,r.onload=()=>{e({get:e=>window.pimcore_studio_ui_bundle.get(e),init:(...e)=>{try{return window.pimcore_studio_ui_bundle.init(...e)}catch(e){console.log("remote container already initialized")}}})},document.head.appendChild(r))})}},__webpack_module_cache__={};function __webpack_require__(e){var t=__webpack_module_cache__[e];if(void 0!==t)return t.exports;var r=__webpack_module_cache__[e]={exports:{}};return __webpack_modules__[e].call(r.exports,r,r.exports,__webpack_require__),r.exports}__webpack_require__.m=__webpack_modules__,__webpack_require__.c=__webpack_module_cache__,__webpack_require__.x=()=>{var e=__webpack_require__.O(void 0,["115","131","791","583","892"],()=>__webpack_require__(9570));return __webpack_require__.O(e)},(()=>{__webpack_require__.federation||(__webpack_require__.federation={chunkMatcher:function(e){return!/^(295|583|892)$/.test(e)},rootOutputDir:"../../"})})(),(()=>{__webpack_require__.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return __webpack_require__.d(t,{a:t}),t}})(),(()=>{__webpack_require__.d=(e,t)=>{for(var r in t)__webpack_require__.o(t,r)&&!__webpack_require__.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})}})(),(()=>{__webpack_require__.f={},__webpack_require__.e=e=>Promise.all(Object.keys(__webpack_require__.f).reduce((t,r)=>(__webpack_require__.f[r](e,t),t),[]))})(),(()=>{__webpack_require__.u=e=>"static/js/async/"+e+"."+({118:"8c2fba98",142:"2705bab0",163:"0886f52f",250:"5d1c8227",417:"d6ff383e",737:"58c8f942",798:"1afd528e",874:"936b3e93",890:"d7d1dc4c"})[e]+".js"})(),(()=>{__webpack_require__.miniCssF=e=>""+e+".css"})(),(()=>{__webpack_require__.g=(()=>{if("object"==typeof globalThis)return globalThis;try{return this||Function("return this")()}catch(e){if("object"==typeof window)return window}})()})(),(()=>{__webpack_require__.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t)})(),(()=>{var e={},t="datadefinitions:";__webpack_require__.l=function(r,o,n,i){if(e[r])return void e[r].push(o);if(void 0!==n)for(var a,s,l=document.getElementsByTagName("script"),c=0;c<l.length;c++){var u=l[c];if(u.getAttribute("src")==r||u.getAttribute("data-rspack")==t+n){a=u;break}}a||(s=!0,(a=document.createElement("script")).timeout=120,__webpack_require__.nc&&a.setAttribute("nonce",__webpack_require__.nc),a.setAttribute("data-rspack",t+n),a.src=r),e[r]=[o];var d=function(t,o){a.onerror=a.onload=null,clearTimeout(p);var n=e[r];if(delete e[r],a.parentNode&&a.parentNode.removeChild(a),n&&n.forEach(function(e){return e(o)}),t)return t(o)},p=setTimeout(d.bind(null,void 0,{type:"timeout",target:a}),12e4);a.onerror=d.bind(null,a.onerror),a.onload=d.bind(null,a.onload),s&&document.head.appendChild(a)}})(),(()=>{__webpack_require__.r=e=>{"u">typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})}})(),(()=>{var e=[];__webpack_require__.O=(t,r,o,n)=>{if(r){n=n||0;for(var i=e.length;i>0&&e[i-1][2]>n;i--)e[i]=e[i-1];e[i]=[r,o,n];return}for(var a=1/0,i=0;i<e.length;i++){for(var[r,o,n]=e[i],s=!0,l=0;l<r.length;l++)(!1&n||a>=n)&&Object.keys(__webpack_require__.O).every(e=>__webpack_require__.O[e](r[l]))?r.splice(l--,1):(s=!1,n<a&&(a=n));if(s){e.splice(i--,1);var c=o();void 0!==c&&(t=c)}}return t}})(),(()=>{__webpack_require__.p="/bundles/datadefinitions/studio/dc01cc000086c9801b2933a986a20c10/"})(),(()=>{__webpack_require__.S={},__webpack_require__.initializeSharingData={scopeToSharingDataMapping:{default:[{name:"@emotion/react",version:"11.14.0",factory:()=>Promise.all([__webpack_require__.e("131"),__webpack_require__.e("583"),__webpack_require__.e("798")]).then(()=>()=>__webpack_require__(6160)),eager:0,singleton:1,requiredVersion:"*",strictVersion:0},{name:"antd",version:"5.29.3",factory:()=>Promise.all([__webpack_require__.e("115"),__webpack_require__.e("163"),__webpack_require__.e("142"),__webpack_require__.e("583"),__webpack_require__.e("295")]).then(()=>()=>__webpack_require__(8237)),eager:0,singleton:1,requiredVersion:"*"},{name:"react-dom",version:"18.3.1",factory:()=>Promise.all([__webpack_require__.e("890"),__webpack_require__.e("583")]).then(()=>()=>__webpack_require__(5985)),eager:0,singleton:1,requiredVersion:"*",strictVersion:0},{name:"react-i18next",version:"14.1.3",factory:()=>Promise.all([__webpack_require__.e("874"),__webpack_require__.e("583")]).then(()=>()=>__webpack_require__(601)),eager:0,singleton:1,requiredVersion:"*",strictVersion:0},{name:"react/jsx-runtime",version:"18.3.1",factory:()=>Promise.all([__webpack_require__.e("583"),__webpack_require__.e("118")]).then(()=>()=>__webpack_require__(9728)),eager:0,singleton:1,requiredVersion:"*",strictVersion:0},{name:"react",version:"18.3.1",factory:()=>__webpack_require__.e("250").then(()=>()=>__webpack_require__(2188)),eager:0,singleton:1,requiredVersion:"*",strictVersion:0},5698]},uniqueName:"datadefinitions"},__webpack_require__.I=__webpack_require__.I||function(){throw Error("should have __webpack_require__.I")}})(),(()=>{__webpack_require__.consumesLoadingData={chunkMapping:{889:["4484","3987","8615"],892:["4535"],295:["9122"],583:["5906"]},moduleIdToConsumeDataMapping:{5906:{shareScope:"default",shareKey:"react",import:"react",requiredVersion:"*",strictVersion:!1,singleton:!0,eager:!1,fallback:()=>__webpack_require__.e("250").then(()=>()=>__webpack_require__(2188))},9122:{shareScope:"default",shareKey:"react-dom",import:"react-dom",requiredVersion:"*",strictVersion:!1,singleton:!0,eager:!1,fallback:()=>__webpack_require__.e("890").then(()=>()=>__webpack_require__(5985))},8615:{shareScope:"default",shareKey:"react/jsx-runtime",import:"react/jsx-runtime",requiredVersion:"*",strictVersion:!1,singleton:!0,eager:!1,fallback:()=>__webpack_require__.e("737").then(()=>()=>__webpack_require__(9728))},4484:{shareScope:"default",shareKey:"react-i18next",import:"react-i18next",requiredVersion:"*",strictVersion:!1,singleton:!0,eager:!1,fallback:()=>__webpack_require__.e("874").then(()=>()=>__webpack_require__(601))},3987:{shareScope:"default",shareKey:"antd",import:"antd",requiredVersion:"*",strictVersion:!1,singleton:!0,eager:!1,fallback:()=>Promise.all([__webpack_require__.e("163"),__webpack_require__.e("142"),__webpack_require__.e("295")]).then(()=>()=>__webpack_require__(8237))},4535:{shareScope:"default",shareKey:"@emotion/react",import:"@emotion/react",requiredVersion:"*",strictVersion:!1,singleton:!0,eager:!1,fallback:()=>__webpack_require__.e("417").then(()=>()=>__webpack_require__(6160))}},initialConsumes:["5906","4535","4484","3987","8615"]},__webpack_require__.f.consumes=__webpack_require__.f.consumes||function(){throw Error("should have __webpack_require__.f.consumes")}})(),(()=>{var e={583:0,889:0,892:0};__webpack_require__.f.j=function(t,r){var o=__webpack_require__.o(e,t)?e[t]:void 0;if(0!==o)if(o)r.push(o[2]);else if(/^(295|583|892)$/.test(t))e[t]=0;else{var n=new Promise((r,n)=>o=e[t]=[r,n]);r.push(o[2]=n);var i=__webpack_require__.p+__webpack_require__.u(t),a=Error(),s=function(r){if(__webpack_require__.o(e,t)&&(0!==(o=e[t])&&(e[t]=void 0),o)){var n=r&&("load"===r.type?"missing":r.type),i=r&&r.target&&r.target.src;a.message="Loading chunk "+t+" failed.\n("+n+": "+i+")",a.name="ChunkLoadError",a.type=n,a.request=i,o[1](a)}};__webpack_require__.l(i,s,"chunk-"+t,t)}},__webpack_require__.O.j=t=>0===e[t];var t=(t,r)=>{var o,n,[i,a,s]=r,l=0;if(i.some(t=>0!==e[t])){for(o in a)__webpack_require__.o(a,o)&&(__webpack_require__.m[o]=a[o]);if(s)var c=s(__webpack_require__)}for(t&&t(r);l<i.length;l++)n=i[l],__webpack_require__.o(e,n)&&e[n]&&e[n][0](),e[n]=0;return __webpack_require__.O(c)},r=self.webpackChunkdatadefinitions=self.webpackChunkdatadefinitions||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),(()=>{__webpack_require__.remotesLoadingData={chunkMapping:{889:["2977","4781"]},moduleIdToRemoteDataMapping:{2977:{shareScope:"default",name:".",externalModuleId:5698,remoteName:"@pimcore/studio-ui-bundle"},4781:{shareScope:"default",name:"./app",externalModuleId:5698,remoteName:"@pimcore/studio-ui-bundle"}}},__webpack_require__.f.remotes=__webpack_require__.f.remotes||function(){throw Error("should have __webpack_require__.f.remotes")}})(),(()=>{var e=__webpack_require__.x,t=!1;__webpack_require__.x=function(){if(t||(t=!0,__webpack_require__(5862)),"function"==typeof e)return e();console.warn("[MF] Invalid prevStartup")}})();var __webpack_exports__=__webpack_require__.x()})();