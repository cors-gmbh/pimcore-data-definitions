
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.datadefinitions = "/bundles/datadefinitions/studio/dc01cc000086c9801b2933a986a20c10/static/js/remoteEntry.js"

      
    